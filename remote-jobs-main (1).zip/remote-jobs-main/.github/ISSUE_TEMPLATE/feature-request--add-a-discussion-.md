---
name: Feature request (Add a Discussion)
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

PLEASE OPEN A NEW DISCUSSION.

[Discussions > New > Ideas](https://github.com/remoteintech/remote-jobs/discussions/new?category=ideas)
