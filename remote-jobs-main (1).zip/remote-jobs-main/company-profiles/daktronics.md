# Daktronics

## Company blurb
Daktronics is a world leader in designing, engineering and manufacturing digital LED display technology and audio systems. We then install and service our reliable, long-lasting digital solutions – from scoreboards and video boards to message displays and billboards – and the intuitive software to control them.

## Company size 
Approximately 1001-5000 employees

## Remote status
Flexible Work Environment, as Fully Remote.
We don’t look at when you log in, log out or how much time you work. We trust you, it’s the only way remote can actually work.

## Region
- USA

## Company technologies
Daktronics uses 34 technology products and services including HTML5, jQuery, and Google Analytics, according to G2 Stack.
Daktronics is actively using 115 technologies for its website, according to BuiltWith. These include Viewport Meta, IPhone / Mobile Compatible, and SPF.

## Office locations
- Brookings, South Dakota

## How to apply
Check out our [careers page](https://www.daktronics.com/en-us/employment/careers) for information about what it is like to work at Daktronics.
