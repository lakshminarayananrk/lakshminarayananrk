# Collabora

## Company blurb

Collabora is a global consultancy consisting of nearly one hundred engineers and developers who leverage Open Source technology to help clients in any number of ways.  

Whether it be through actual code or even strategic software development planning, they're goal is to help create quality solutions that help power leading products across many different industries used in millions of devices all over the world. 

## Company size

100 (as of 2020)

## Remote status

Collabora consists of a globally distributed team of engineers and developers who are passionate about working with clients around the world.

## Region

Worldwide

## Company technologies

Any software engineering or development expertise welcome, as long as you have a passion for technology and Open Source!

## How to apply

Career opportunities can be found on [the careers page](https://www.collabora.com/careers.html)!