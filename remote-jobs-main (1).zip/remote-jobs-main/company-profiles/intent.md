# Intent

## Company blurb

[Intent](https://withintent.com/) has over 10+ years of experience in helping to conceptualize, design, and build apps for IoT and connected devices.

## Company size

50-100 people

## Remote status

Remote first

## Region

Europe, Africa

## Company technologies
   
* IoT
* iOS (Obj-c, Swift)
* Android (Java, Kotlin)
* Flutter
* React Native
* AWS
* Node.js

## Office locations

Warsaw, Wilcza 46


## How to apply

[Intent Careers](https://withintent.com/careers)
