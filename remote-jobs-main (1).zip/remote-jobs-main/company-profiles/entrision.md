# Entrision

## Company blurb

Entrision is a software development agency that partners with innovative organizations to create unique, hand-crafted software applications for web and mobile platforms.

Our product designers and software engineers work with our clients to design and build web and mobile applications that meet the unique needs of your business and solve real-world problems.

## Company size

1-20

## Remote status

The majority of our team works remotely, and our team members are currently spread across 6 different states.

## Region

USA

## Company technologies

Ruby on Rails, Javascript, Node, Swift, Kotlin

## Office locations

HQ in Milwaukee, WI

## How to apply

Email your resume to theteam@entrision.com and tell us about your favorite pizza topping.
