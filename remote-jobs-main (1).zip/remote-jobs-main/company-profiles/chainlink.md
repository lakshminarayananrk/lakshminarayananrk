# ChainLink Labs

## Company blurb

We’re a world-class team of results-oriented developers, academics, seasoned executives, and startup operators who are building next-generation data infrastructure for smart contracts.

## Company size

200+ (as of January 2020)

## Remote status

Almost all of us are remote. Headquarters in San Francisco, CA

## Region

All roles with Chainlink Labs are globally remote based. We encourage you to apply regardless of your location.

## Company technologies

Javascript, Python, Golang, TypeScript, Solidity, Postgres, Terraform, AWS

## Office locations

San Francisco, CA

## How to apply

Check our careers page: https://chainlinklabs.com/jobs
