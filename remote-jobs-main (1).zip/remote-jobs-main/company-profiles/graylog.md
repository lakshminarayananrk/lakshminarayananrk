# Graylog

## Company blurb

Graylog is an open source, centralized log management alternative to Splunk. 

## Company size

20-50

## Remote status

100% remote

## Region

**Worldwide**

## Company technologies

* Java
* MongoDB
* ReactJS/Javascript

## Office locations

Houston, TX

## How to apply

Go to [this](https://www.graylog.org/careers) page, click on a job you're interested in then fill out the form at the bottom of the page to apply.