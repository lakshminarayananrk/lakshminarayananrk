# KissMetrics

## Company blurb

KissMetrics is focused on helping marketers improve their performance.

## Remote status

Most of the team works remotely and everyone has the option of working remotely or from the Headquarters in San Francisco (snacks, nap room, video game room, and a puppy included at HQ!).

## Region

Primarily based out of San Francisco, but KissMetrics have a strong remote presence all throughout the world.

## Company technologies

Javascript, React, jQuery, Backbone, Git, Distributed systems, PostgresSQL, MySQL, Key-Value Stores, R, Ruby, Python, etc.

## Office locations

Headquarters in San Francisco, USA.

## How to apply

[careers site](https://www.kissmetrics.com/careers/)
