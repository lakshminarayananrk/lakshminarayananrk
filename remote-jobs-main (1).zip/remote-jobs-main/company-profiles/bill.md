# Bill

## Company blurb

Bill.com is a leading provider of cloud-based software that simplifies, digitizes, and automates complex, back-office financial operations for small and midsize businesses.

## Company size

0 - 1000

## Remote status

Bill.com works to provide a “casual, fun environment” at its Palo Alto office, including healthy snacks; an open, inclusive workspace; onsite fitness and running trails; and, for all employees, flexible work schedules.

## Region

Currently we are only set up for US-based remote employees.

## Company technologies

Java, AWS, DynamoDB

## Office locations

USA

## How to apply

[Bill Jobs](https://www.bill.com/about-us/careers/)
