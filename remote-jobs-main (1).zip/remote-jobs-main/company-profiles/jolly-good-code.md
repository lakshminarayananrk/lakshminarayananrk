# Jolly Good Code

## Company blurb

We have the passion and confidence to train you to be a software engineer.

## Company size

0-20

## Region 

Worldwide

## Company technologies

Ruby on rails 

## Office locations

Singapore

## How to apply

Send an E-mail to winston@jollygoodcode.com to get in contact 
