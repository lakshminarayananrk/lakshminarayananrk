# Fiverr

## Company blurb

Fiverr is a global platform connecting businesses with on-demand freelancers in the simplest way possible, helping anyone anywhere succeed.

## Company size

201 - 500

## Remote status

Work in the place that makes you happy, that inspires you daily and that helps you become the person you want to be. We were born with 100% 
remote teams and we always will be.

## Office locations

North America, Asia

## Company technologies

 HTML/ CSS / Javascript / Typescript / React.js / Node.js / Ruby / Java / Kotlin

## How to apply

[Fiverr Careers](https://www.fiverr.com/jobs/teams)
