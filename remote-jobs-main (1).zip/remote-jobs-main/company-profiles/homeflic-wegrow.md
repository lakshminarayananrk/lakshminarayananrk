# Homeflic wegrow

## Company blurb

WE ARE THE YOUTH with a vision of personal growth along with the growth of people around us. Our main objective as a tribe is to reach out to young curious minds and help and guide them in every way possible. Working to uplift the youth by creating this community to solve real life problems of millennials and society when there’s no one else who can better understand their deeds. We are people who wish to teach as well as learn and build a tribe where everyone is equal.

A team with diverse, young and fresh minds building an environment where we have people who contribute in acting upon the ideas of growth. At Wegrow we walk towards the path of success together and that is why we always say, “Here We Go, Here We Grow”.

## Company size

1- 50 (as of January 2020)

## Remote status

Almost all of us are remote. We also have an office in India (New Delhi) that everone is welcome to use when they're in the city, but even India locals pop in just a few days a week.

## Region

Current openings are for remote positions in Mumbai.

## Company technologies

WordPress, HTML code, JavaScript, PHP, MySQL,Node.js, React, Microservices, ReactNative, .NET.

## Office locations

India

## How to apply

Check our jobs page: https://www.homeflicwegrow.com/hiring/
