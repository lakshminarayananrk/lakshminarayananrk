# EPAM

## Company blurb

Since 1993 EPAM helps customers to grow. Our end-to-end services combine business and innovation strategy, experience design, technology consulting and best-in-class software engineering to deliver results on a global scale.

## Company size

30000+ people

## Remote status

Partially, details available on subdomain https://anywhere.epam.com/
Work and Learn
Anywhere with EPAM
After 25+ years of leading the world in product engineering, we’re bringing our experience, training and global customers to you. Anywhere.

## Region

Worldwide

as of March 2020: Russia, Belarus and Ukraine

## How to apply

https://anywhere.epam.com/
