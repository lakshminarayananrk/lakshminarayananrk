# Bluespark

## Company blurb

Bluespark is a company that was founded in 2009 and provides with IT services. The company specialises in 
UX design, open source development, e-commerce.

Specialities:
Enterprise Content Management Systems, HigherEd Libraries, E-commerce, Universities, Libraries, Outdoor Brands, Open Source Development, Online Retail, and Digital Customer Journey Design

## Company size

11 to 50

## Remote status

Hiring to work from anywhere:
1) Senior Drupal developer
2) Project Manager
3) Front end developer

## Region

USA

## Office locations

1) Bluespark 324 S. Wilmington St. #242
   Raleigh, NC 27601, US

2) Austin, TX 78619, US

## How to apply

Apply [here](https://www.bluespark.com/careers)