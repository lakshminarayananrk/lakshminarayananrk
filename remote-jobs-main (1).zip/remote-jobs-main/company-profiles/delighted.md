# Delighted

## Company blurb

Delighted is a company which provides software that can gather actionable feedback from your customers. Customers take a single question survey. They rate your product/service and provide feedback in their own words. Feedback appears instantly in your dashboard.

## Company size

100-200

## Region

* USA
* Asia
* Europe

## Company technologies

NPS,
CSAT,
CES,
5-star,
Smileys,
Thumbs,
Email,
Web,
SMS,
Link,
iOS SDK

## Office locations

Benelux,
Buenos Aires,
Canberra,
Chicago,
Dallas,
Dublin,
India,
Italy,
Krakow,
London,
Mexico City,
Munich,
New York,
Paris,
Provo,
Raleigh,
Remote,
São Paulo,
Seattle,
Singapore,
South Korea,
Spain,
Sydney,
Thailand,
Tokyo,
Toronto,
Washington D.C. 

## How to apply

https://delighted.com/jobs
