# Filament Group

## Company blurb

Filament Group is a design and front-end development studio. Since 2001 we’ve been designing and developing a wide range of sites and apps for big companies, innovative startups, and open-source projects.

## Company size

Six-member team as shown on the [who we are page](https://www.filamentgroup.com/about/).

## Region

USA

## Office locations

Boston, MA

## How to apply

No job openings are listed on their website, but there is a contact email.
