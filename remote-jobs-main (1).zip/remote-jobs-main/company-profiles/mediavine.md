# Mediavine

## Company blurb

Mediavine is an advertising management company representing over 5500 websites in the food, lifestyle, DIY, and entertainment space.

## Company size

67 employees as of October 2019.

## Remote status

100% remote with headquarters in Boca Raton, Florida.

## Region

Employees are distributed throughout North America.

## Company technologies

JavaScript, PHP, SQL, Slack, Intercom.

## Office locations

Boca Raton, Florida

## How to apply

Openings page: https://mediavine.workable.com/
