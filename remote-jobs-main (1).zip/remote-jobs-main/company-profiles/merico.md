# Merico

## Company blurb

Merico is committed to empowering every developer in the world to create more value.

We believe the software development process and developer competence are reflected in developer contribution to software projects, so we built the most advanced and trusted contribution analysis engine for software development. Old analytics measure surface level signals. Merico directly analyzes the code, measuring what matters with deep program analysis.

Better software development empowered with deeper insights.

## Company size

1-50 Employees

## Remote status

We are working almost 100% remotely.

(We have been working remotely ever since the company was founded.)

## Region

Worldwide

## Company technologies

Python/Node.JS/SQL

JavaScript/React

## Office locations

We have offices in San Francisco (US) and BeiJing (CN).

## How to apply

Please don't hesitate to send an email to: hello@merico.dev .
