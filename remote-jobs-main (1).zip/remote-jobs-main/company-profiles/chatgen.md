# ChatGen

## Company blurb

ChatGen is a Smart Conversational Sales and Marketing Chatbot platform that drives immediate business impact with Sales. Our ChatGen solution is just not an ordinary chatbot but an advanced chatbot clubbed with features like automatic scheduling, extensive analytics, automatic routing, and a host of other features.

## Company size

<30 (as of February 2021)

## Remote status

Almost all of us are remote, distributed around Asia and USA.

## Company technologies

JavaScript, AWS Lambda, Cloudwatch, Node.js, React.js, MongoDB, Django

## Office locations

India

## How to apply

See our job listings at https://www.linkedin.com/company/chatgen/jobs/
