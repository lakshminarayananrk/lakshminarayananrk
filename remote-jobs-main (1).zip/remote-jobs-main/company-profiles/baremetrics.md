# Baremetrics

## Company blurb

Who we are, what we’re about & what we do, yo. Baremetrics is pretty much the bee’s knees. We're the best Stripe analytics tool out there. Period.
We are a small, tightknit team. We are proud of every piece of work that rolls out. We know what we want to build, where it should go and how we’ll get there. We go out, kill it and drag it home.
Since launching, we’ve added some great customers, received some killer press and are hiring like crazy. We’re growing fast, and have been since day 1. So, if you’d like to chat about what it’s like here, who works here, why it matters and what our favorite snacks are...just reach out.

## Company size

5!

## Remote status

[100% Remote](https://baremetrics.com/jobs)

## Region

Worldwide.

## Company technologies

PHP, jQuery

## Office locations

None, 100% remote.

## How to apply

Jobs and info is posted at the [jobs page](https://baremetrics.com/jobs)
