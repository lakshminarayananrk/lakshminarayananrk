# Alami

## Company blurb

Achieve purpose through the ethical P2P lending. Connecting funders and business owner through ethical-complied projects to a fairer and a more transparent finance.

## Company size

500+

## Remote status

* Remote working, forever. Work from home or café, it doesn't matter.
* Four-day Workweek. Friday to Sunday are weekends for spend more time for worship & family.

## Region

Indonesia, South East Asia

## Company technologies

Go, Java, Spring Boot, Kotlin, Javascript, Python

## Office locations

Jakarta, Indonesia. We are 100% remote, #WorkFromAnywhere you want.

## How to apply

Career site: https://alamisharia.co.id/en/career/