# messagebird

## Company blurb

MessageBird’s mission is to create a world where communicating with a business is as easy as talking with a friend. We power communication between businesses and their customers — across any channel, always with the right context, and on every corner of the planet.

## Company size

800+ employees

## Remote status

The team is remote and in person, located in Amsterdam and 55 other countries.

## Region

Worldwide

## Company technologies

Our platform, our applications and our APIs help businesses streamline conversations through their customers’ preferred channels — like WhatsApp, Email, SMS, Voice, WeChat, Messenger, Instagram - and build powerful and engaging experiences.

## How to apply

[Click Here to apply](https://messagebird.com/careers#jobs)
