# MeridianLink

## Company blurb

The MeridianLink platform features SaaS cloud-based products and services that span the entire digital lending journey, end-to-end. Our industry-trusted digital lending, deposit account opening, collections, and data solutions—for consumer and mortgage lending—easily integrate within our platform.

## Company size

700 - 800 (Oct 2022)

## Remote status

Full time in US.

## Region

United States

## Company technologies

The MeridianLink One platform delivers ROI for lenders of all sizes. MeridianLink provides streamlined digital lending experience for Banks, Credit Unions and Mortgage Lenders.

## Office locations

- 3560 Hyland Ave - Suite #200, Costa Mesa, CA 92626

## How to apply

https://www.meridianlink.com/careers
