# Dave

## Company blurb
Dave is a banking app on a mission to build products that level the financial playing field.We started Dave for one reason: banks weren’t built for people like us, and we knew we deserved better. Like David slaying Goliath, we’re taking on big banks and their predatory ways.
checkout company's about us page [here](https://dave.com/about).

## Company size
Its approximately 201-500 employees.

## Remote status 
Flexible Work Environment, its fully remote job 
At Dave, our people are just as important as our product. Our culture is a reflection of our values that guide who we are, how we work, and what we aspire to be

## Region 
- US

## Company technologies
Dave uses 23 technology products and services including HTML5, jQuery, and Google Analytics, according to G2 Stack.
Dave is actively using 40 technologies for its website, according to BuiltWith. These include WordPress, Amazon, and Font Awesome.

## How to apply
Check out our [careers page](https://dave.com/careers) for information about what it is like to work at Dave
