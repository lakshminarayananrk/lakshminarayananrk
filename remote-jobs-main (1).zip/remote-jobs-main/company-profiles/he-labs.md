# HE:labs

## Company blurb

We are a team of agile designers and developers, and we can turn your idea into a great digital product!. Let's do something special together.

## Company size

50+

## Remote status

100% Remote. We also have a beautiful office in (Rio)[https://journal.helabs.com/what-if-your-company-takes-you-to-rio-de-janeiro-966e9ec4a1aa#.20slfxsp2]

## Region

Worldwide

## Company technologies

Ruby, Clojure, Elixir, JavaScript, HTML5, CSS3, Postgres, Heroku, AWS, GCE, Docker, Kubernetes

## Office locations

Rio de Janeiro, BRA

## How to apply

HE:labs have a [careers page](https://helabs.com/br/trabalhe-conosco)
