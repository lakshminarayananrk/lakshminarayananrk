# Mixcloud

## Company blurb

We are a fair and legal platform that supports creators to share their passions in music. This is where people come to listen deeply across every genre, taste and scene. Our mission is to get more fans directly supporting creators. We're empowering the people behind the music to cultivate meaningful relationships with their own fan communities, so they can make more together. We want to see a world where everyone can create sustainably and connect deeply. Beyond the algorithm, human to human.

## Company size

100-200 people

## Remote status

Partially remote mainly on site

## Region

Europe

## Company technologies

Python
Django
React
JavaScript

##Office locations

London,England

## How to apply

To apply to mixcloud click here https://apply.workable.com/mixcloud-limited/