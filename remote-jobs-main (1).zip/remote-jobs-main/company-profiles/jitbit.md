# Jitbit

## Company blurb

Jitbit is a helpdesk app that tries to help people do their jobs better instead of being just another tool their boss made them use. We value clean design and ease of use the most.

## Company size

0-10 employees

## Remote status

The entire team works remotely from different cities around the world.

## Region

Worldwide

## Company technologies

C#, ASP.NET MVC, ASP.NET Core, Javascript, Angular, Typescript, Ionic, Python

## Office locations

We do not have an office - everyone chooses where they want to work from.

## How to apply

Send an email to info@jitbit.com.
