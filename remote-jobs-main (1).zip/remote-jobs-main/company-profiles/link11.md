# Link11

## Company blurb

Link11 is the leading European IT security provider in the field of cyber resilience. We offer a broad portfolio of proven services that protect web applications and server infrastructures from malicious attacks. Our protection solutions are fast, intelligent and demonstrably secure.

## Company size

As of October 2021, the company has around 65 employees.

## Remote status

Employees can work fully remote according to their role, while we also have great team events that you don't want to miss!

## Region

We have team members all over Germany.

## Company technologies

C, C++, Python, PHP, JavaScript, Postgres, Clickhouse, Git, Docker.

## Office locations
We have offices in Hamburg and Frankfurt, for those who prefer an offices workspace.


## How to apply

[Apply online for any of the jobs on our careers page!](https://www.link11.com/en/career/)
