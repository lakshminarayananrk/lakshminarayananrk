# Coodesh

## Company blurb

Coodesh was born with the purpose of helping other companies build the best and most diverse technology teams. We believe that in the current 
context of startups and digital transformation of large companies, efficient tech recruitment with relevant insights for the evolution of hired people 
is one of the biggest differentials for success.

## Company size

11 - 50

## Remote status

Work in the place that makes you happy, that inspires you daily and that helps you become the person you want to be. We were born with 100% 
remote teams and we always will be.


## Office locations

Brazil

## Company technologies

 HTML/ CSS / Javascript / Typescript / React.js / React Native / Vue.js / Node.js / PHP / Laravel

## How to apply

[Linkedin Jobs](https://www.linkedin.com/company/coodesh/jobs/)

[Coodesh Vacancies](https://coodesh.com/vagas)
