# Lincoln Loop

## Company blurb

We're a full service web studio offering user experience and development based on the Django Web Framework. We believe in delivering quality solutions via a lean and transparent process. Our team is passionate about building exceptional web sites and applications.

## Company size

11-50

## Remote status

We offer full-time and remote jobs with 100% remote status.

## Region

USA

## Company technologies

Python and Django.

## Office locations

Chicago, Illinois, US

## How to apply

Email us:

info@lincolnloop.com

Include:

* your resume or Linked profile
* link to your Open Source codes
* your hourly rate

Keep an eye for new Job postings:

https://lincolnloop.com/
