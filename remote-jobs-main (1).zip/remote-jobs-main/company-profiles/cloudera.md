# CloudEra

## Company blurb
Explore opportunities at Cloudera
We’re on a mission to make data and analytics easy and accessible to everyone. The work we do empowers any organization – from the world's largest enterprises to small nonprofits –  to use data to solve some of the most complex challenges that impact businesses, communities and lives.

## Company size
3000

## Remote status
Global locations
Cloudera has corporate offices in 8 U.S. states and 19 countries around the world.
Remote positionas are available on job portal.

## Region
Worldwide.

## Company technologies
Datalakes, data mesh, data platforms, enterprise AI

## Office locations
Worldwide

## How to apply
Check our jobs page: https://cloudera.wd5.myworkdayjobs.com/External_Career?remoteType=648856a73acb1001a30bbdb5cbb70002
