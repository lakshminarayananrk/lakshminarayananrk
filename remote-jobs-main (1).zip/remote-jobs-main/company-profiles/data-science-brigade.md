# Data Science Brigade

## Company blurb

A Data Science consultancy boutique, that is responsible for one of the most popular projects about civic tech in Brazil - [Operação Serenata de Amor](https://serenatadeamor.org/)

## Company size

Around 10 employees.

## Remote status

We have people working at: Milan, Italy; São Paulo, Brazil; Porto Alegre, Brazil and Cambridge, USA

## Region

Worldwide - We have employees that work from the America to Europe, and even some of us are working nomadic by now :)

## Company technologies

- Python
- Django
- Git

## Office locations

- Milan, Italy
- São Paulo, Brazil
- Porto Alegre, Brazil
- Cambridge, USA

## How to apply

More information can be obtained by [our website](https://dsbrigade.com/)!
