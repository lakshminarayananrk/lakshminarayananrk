# JBS Custom Software Solutions

## Company blurb

Founded in 1999, JBS is a group of highly skilled developers who work together in a virtual, fully remote environment distributed across the US. JBS provides custom software systems to technology driven companies.

## Company size

50-100

## Remote status

JBS has been fully remote for its entire 20+ year history. 

## Region

USA

## Company technologies

Python, Node.js, React, .NET, AWS, Azure, PostgreSql, MySql

## Office locations

100% Remote

## How to apply

Learn more about us and apply today! https://www.jbssolutions.com/careers/
