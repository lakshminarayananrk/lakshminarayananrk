# Medium

## Company blurb

Medium taps into the brains of the world’s most insightful writers, 
thinkers, and storytellers to bring you the smartest takes on topics 
that matter. So whatever your interest, you can always find fresh 
thinking and unique perspectives.

## Company size

100+

## Remote status

Remote-friendly, some positions available in the US.

## Region

US only

## Company technologies

Go, Python, Javascript (Node.js, React or GraphQL), AWS (RDS, SQS, DynamoDB), Kubernetes, Mesos or ECS

## Office locations

San Francisco, NY

## How to apply

Medium has a [careers page](https://jobs.lever.co/medium?team=Engineering) and a [dedicated blog](https://medium.com/jobs-at-medium)


