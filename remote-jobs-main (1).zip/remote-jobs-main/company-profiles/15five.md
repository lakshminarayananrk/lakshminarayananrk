# 15Five

## Company blurb

#### [About Us](https://www.15five.com/company)
15Five makes continuous employee feedback simple to drive high performing cultures.

#### Our Mission
Join our mission to create the spaces where people become their greatest selves, by joining some of the greatest employees around.

## Company size

~100 currently (5/3/2019) and growing

## Remote status

Over half of company works remote. We communicate via [slack](https://www.slack.com) and have a yearly company retreat. We also provide health benefits through [zestful](https://zestful.com) that can be used for a gym or other activities.

## Region

The Americas and Europe. 

## Company technologies

Backend: Python, Django

Frontend: Django templates, React

Devops: AWS, ansible

## Office locations

New York, San Francisco, Lviv (Ukraine)

## How to apply

[15Five careers page](https://www.15five.com/careers/)
