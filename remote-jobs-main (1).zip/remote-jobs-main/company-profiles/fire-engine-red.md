# Fire Engine Red

## Company blurb

Fire Engine RED is a fully remote marketing, data, technology, and consulting services company that’s served the education market since 2001. Our services and products are used by more than 300 educational institutions.

## Company size

70+ Employees

## Remote status

Fully remote company with teammembers working/living in the U.S, Brazil, Canada and Peru. The goal ist to empower team members to do their best.
At Fire Engine RED, we value diversity and believe that employing people who have different perspectives and life experiences makes us a better, more innovative company. So, no matter your race, religion, ethnicity, nationality, culture, gender, gender identity, sexual orientation, age, or disability, we value you and your skills, and hope you apply.

## Region

Worldwide

## Company technologies

No specific Information on what technologies are used and what is skill set they seek in new employees.

## Office locations

Headquarter in Havertown, U.S.

## How to apply

https://fire-engine-red.com/general-contact-form/
https://fire-engine-red.com/submit-rfp/
