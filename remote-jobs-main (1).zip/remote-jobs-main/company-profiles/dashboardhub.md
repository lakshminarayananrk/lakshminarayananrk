# DashboardHub

## Company blurb

Your Delivery Pipeline overview in One Place. If you are delivering a platform or a library, know exactly WHAT, WHEN and WHERE are being built and deployed, by reporting back to your Pipeline Dashboard (currently in Alpha) on DashboardHub.

## Company size

1-20 all fully remote.

## Remote status

All roles are fully remote. We use GitHub and Slack for team collaboration. The team get together when they see fit or at events.

## Region

Worldwide

## Company technologies

- node
- serverless
- aws lambda & dynamodb
- angular
- material design

## Office locations

None; or everywhere!

## How to apply

Website http://dashboardhub.io
