# addstructure 

## Company blurb

We bring a people-first approach to advanced technology, connecting thousands of brands and retailers to the voices of their customers.

## Company size

5-10

## Remote status

Redefining how brands and consumers connect, create and innovate

## Region

USA

## Company technologies

iOS, React, Knockout, Rails, Perl, HTML, Sql, Ruby, JQuery

## How to apply

Visit https://www.bazaarvoice.com/
