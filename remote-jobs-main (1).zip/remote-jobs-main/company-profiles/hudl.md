# Hudl

## Company blurb

Online video analysis tools that help coaches at any level in every sport win.
Hudl is a sports + technology company. We create software that helps coaches win, athletes look like pros, and recruiters find more talent.

## Company size

393 team members listed by department on the [about/team](http://get.hudl.com/about/team/) page.

## Remote status

Currently, working remotely is available to product team members in six states and the United Kingdom: CA, MA, NE, NY, TX, WA

## Region

US and UK based employees.

## Company technologies

Hudl keep a GitHub pages site [hudl.github.io](http://hudl.github.io/) showing their Open Source projects and technology

## Office locations

We’re headquartered in the Haymarket District of Lincoln, Nebraska.

## How to apply

All Hudl jobs are on the [Join us](http://public.hudl.com/jobs) page.
