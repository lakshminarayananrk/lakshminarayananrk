# Grafana Labs

## Company blurb

Grafana Labs is the company behind Grafana, the leading open source software for visualizing time series data.

## Company size

186 employees, according to LinkedIn (October 2020).

## Remote status

The company is remote first.

## Region

United States and EMEA/EST Timezones.

## Company technologies

Go, JavaScript, React, Redux, RxJS, Webpack

## Office locations

Headquarters in New York, NY.

## How to apply

Openings page: https://grafana.com/about/careers/?plcmt=footer#jobs
