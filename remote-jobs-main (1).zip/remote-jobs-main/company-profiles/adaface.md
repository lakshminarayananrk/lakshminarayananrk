# Adaface

## Company blurb

Adaface helps companies identify top engineers by automating the hiring process. We automate screening with Ada, a conversational AI for first round tech interviews. For second round interviews, we provide [remote pair programming tool](https://www.adaface.com/pair-pro) with video conference, code compiler and shared editor.

## Company size

0-20

## Remote status

Completely remote from 2019.

## Region

Asia

## Company technologies

ReactJs, Socket.IO, Firebase, MySQL, Docker, Django, MongoDb

## Office locations

- 32 Carpenter Street, Singapore
- Innov8 Coworking, Koramangala, Bangalore, India

## How to apply

https://angel.co/company/adaface/jobs
