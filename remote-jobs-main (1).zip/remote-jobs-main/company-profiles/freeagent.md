# Freeagent

## Company blurb

FreeAgent is one of the UK's largest, and most popular, online accounting services, helping thousands of freelancers and small businesses manage their company accounts in our unique, simple, stress-free way. We're going from strength to strength, and we're on track to fundamentally change the relationship small businesses have with their accounts.

## Company size

61 listed on Freeagent [About Us](http://www.freeagent.com/company/about-us)

## Region

Scotland, UK based company, remote worldwide

## Office locations

FreeAgent
One Edinburgh Quay
133 Fountainbridge
Edinburgh
Scotland United Kingdom
EH3 9QG

## How to apply

Freeagent [jobs](http://www.freeagent.com/company/jobs/)
