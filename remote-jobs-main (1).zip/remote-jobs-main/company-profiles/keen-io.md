# Keen IO

## Company blurb
There’s no need to rebuild a data pipeline, Keen already built one for you. Take advantage of our fully-managed, multi-tenant data architecture and get back to building awesome apps.

Keen is the customer-facing metrics platform that makes shipping custom end-user analytics easy and seamless.

## Company size
51-200 employees

## Region
USA

## Company technologies
Analytics, Big Data, Data Science, Developer Tools, APIs, and Data Visualization

## Office locations
San Antonio, Texas

## How to apply
Job listings:
https://scaleworks.com/careers/

Contact:
https://www.linkedin.com/company/keen-io/


https://keen.io/