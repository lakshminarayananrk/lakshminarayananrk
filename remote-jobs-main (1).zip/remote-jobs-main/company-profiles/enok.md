# Enok Collective

## Company blurb

We are passionate about launching people and launching products. We amplify the human experience. Our designers, developers, & storytellers deliver exceptional solutions for digital advantage. We discover, experiment, and launch. Time-traveling with interdisciplinary teams, we generate new ideas and breakthroughs.

## Company size

20-50

## Remote status

We are a remote-first company with "hubs" in Peoria, IL and Greenville, SC.

## Region

Employees are accepted within a 3-hour radius of our hubs in **USA**

