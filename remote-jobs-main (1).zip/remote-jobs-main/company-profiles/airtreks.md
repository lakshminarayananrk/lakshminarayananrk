# airtreks

## Company blurb

Since 1987, AirTreks has been a leader in multi-stop international travel, especially complex routes with up to 25 stops. We believe travel is vital: our core values are making meaningful connections, embracing change, working and playing with passion, loving learning, and owning our experience.

## Company size

11-50

## Remote status

Multi-stop international flight planner with a distributed team.

## Region

USA

## Company technologies

Full-Stack Developer, Travel Service Expert,Experienced Travel Agent,Travel Ambassador 

## How to apply

Visit https://airtreks.com/about/jobs-at-airtreks/
