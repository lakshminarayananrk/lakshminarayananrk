# Maxicus

## Company blurb

[Maxicus](https://maxicus.com/) intelligently blend the human EQ and machine IQ to foster interactions that last in your customers’ memories.
Takes  customer experience a notch above by building exceptional engagement at both assisted and digital channels.

## Company size

~250 employees (as of Oct 2020).

## Remote status
 Remote employement is provided.

## Region

India

## Company technologies

PHP, Laravel, MySQL, Git,Big Data,C#,Java and Python Programming

## Office locations

The main offices are located in Gurgaon.

## How to apply

Visit our [Contact Page](https://remoters.net/jobs/maxicus/)
