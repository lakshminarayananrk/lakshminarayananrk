# Bit Zesty

## Company blurb

[Bit Zesty](https://bitzesty.com/) a digital service design and development agency that uses technology to have a positive impact on society. We're a multi-disciplinary team of developers, consultants and user experience specialists.

## Company size

20+

## Remote status

Fully remote team with HQ in London.

## Region

Worldwide.

## Company technologies

Ruby on Rails, Node.js, React.js, React Native, Vue.js, Python, Django, Elixir

## Office locations

70 White Lion Street
London
N1 9PP
United Kingdom

## How to apply

[Career Opportunities at Bit Zesty](https://bitzesty.com/careers/)
