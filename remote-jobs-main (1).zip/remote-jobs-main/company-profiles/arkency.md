# Arkency

## Company blurb

Arkency is a consulting agency.

## Company size

0-20.

## Remote status

Employees can work from anywhere in the world and they offer flexible working hours.

## Region

Worldwide

## Company technologies

Ruby on Rails, React.js, Redux

## Office locations

None.

## How to apply

https://blog.arkency.com/join-our-team/
