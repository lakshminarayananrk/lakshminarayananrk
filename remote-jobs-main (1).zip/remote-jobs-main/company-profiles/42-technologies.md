# 42 Technologies

## Company blurb

42 is an end-to-end analytics stack for retailers and brands.

## Company size

0-20 employees

## Remote status

Full remote company. In person team retreats at least twice a year.

## Region

**Worldwide** and that can overlap ~4hrs with San Francisco Timezone (Pacific Time).

## Company technologies

- Python
- TypeScript
- Node.js
- Apache Spark
- SQL
- AWS
- GCP
- Docker, K8s

## Office locations

San Francisco, US

## How to apply

[https://angel.co/company/42](https://angel.co/company/42)
