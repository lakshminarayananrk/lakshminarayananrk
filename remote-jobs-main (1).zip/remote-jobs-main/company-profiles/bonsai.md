# Bonsai

## Company blurb

Bonsai is an all-in-one tool for freelancers and agencies, helping them manage their solo and small business.

Bonsai provides a desktop and mobile software to manage contracts, invoices, proposals and payments in a single dashboard.

## Company size

11-50

## Remote status

The team is currently located in the US, Brazil, Canada, Romania, India, Portugal and Spain. The team is flexible but every new hire has to share at least 4h in their day with the rest of their team.

## Region

Worldwide

## Company technologies

Rails, React, React Native, Electron, Postgres

## How to apply

Email contact@hellobonsai.com with "Spontaneous application (Remote jobs)"
