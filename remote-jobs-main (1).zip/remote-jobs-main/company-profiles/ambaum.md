# Ambaum

## Company blurb

[Ambaum](https://ambaum.com) is a Web Development agency with a focus on e-commerce.

## Company size

10-20

## Remote status

We have an office in Seattle and for those who live locally, working remote is an option. However most of the local developers choose to work at the office. There are also a few 100% remote developers.

## Region

Worldwide. Right now we have developers in North America and Europe. Most of them are in Seattle but we also have one in Germany and two in Arizona. More are welcome.

## Company technologies

HTML, CSS, SCSS, JavaScript, jQuery, React, Vue, Node, Express, Koa, PHP, MySQL, MongoDB

## Office locations

Seattle, Washington, USA

## How to apply

[Ambaum Careers](https://ambaum.com/careers)
