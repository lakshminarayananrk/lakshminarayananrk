# DealDash

## Company blurb

DealDash is an e-commerce company located in Minneapolis, Minnesota that has been in operation since 2009. The online bidding auction site, DealDash, has offered remote work options in the past and currently employs over 50 individuals. As an auction site, DealDash provides users with an entertainment service and buying opportunities for numerous products.

## Company size

50+

## Remote status

Remote working available for a number of different roles including tech jobs and customer support.

## Region

Worldwide

## Office locations

- Minneapolis, Minnesota

## How to apply

Check out our available positions at: [DealDash Careers](https://www.dealdash.com/careers)
