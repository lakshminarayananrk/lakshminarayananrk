# Jaya Tech

## Company blurb

We are a dev shop (more like a dev family) specialized on startups / disruptive projects. We deliver value by composing teams (squads) with our developers and client's product managers.

## Company size

70 - 100

## Remote status

The entire team works remotely from different cities around the world.

## Region

Worldwide.

## Company technologies

Kotlin, Ruby, JS, Clojure and Elixir.

## Office locations

São Paulo, SP.

## How to apply

See the [site](http://jaya.tech) for available positions.
