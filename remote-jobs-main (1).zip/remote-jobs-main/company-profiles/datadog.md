# Datadog

## Company blurb

Cloud-Scale Monitoring - Monitoring that tracks your dynamic infrastructure and applications.

We tackle some of the hardest technical problems while delivering a product that "just works" for our customers. And we are backed by some of the best VCs in NYC and the world.

Do you want to make a difference? Are you exceptional at your job, and intrinsically motivated by it? Do you eat hard problems for breakfast and find them beautifully simple solutions by lunchtime? Do you ever wish you were there in the early days of these startups everyone is talking about?

## Remote status

Part remote given job openings

## Region

Worldwide given job openings. All open locations for each role are listed on the role description.

## Office locations

New York City - Headquarters
Datadog, Inc. • 620 8th Ave, 45th Floor • New York, NY 10018

## How to apply

https://www.datadoghq.com/careers/detail/
