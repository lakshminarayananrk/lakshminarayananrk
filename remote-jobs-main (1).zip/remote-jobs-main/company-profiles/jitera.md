# Jitera

## Company blurb

We are nocode start up and incubator of a lots of web service. Our services are:

+ Create code automation platform. *not open now. using only inside company
+ Create web service (client work) using code automation tool by us.

## Company size

35-50

## Remote status

Our team is fully remote. Our CEO & Office in Japan, so the company was built with the assumption of being remote. We do have a cluster of people in some places, like Viet Nam, India, Japan, but the culture is around being anywhere.

## Region

For technical hires, we're looking anywhere all around the world. 

## Company technologies
- React
- React native
- Ruby, ruby on rails
- Golang
- Nodejs
- MySQL

## Office locations

Our Offices only in Japan.

## How to apply

- Jobs: https://angel.co/company/iruuza/jobs
