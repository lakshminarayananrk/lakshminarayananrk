# Acivilate

## Company blurb

We are an Enterprise Software company committed to helping people working with people. Our flagship product is Pokket℠. Pokket℠ helps returning citizens, service providers, and correctional supervision work together to improve outcomes and reduce recidivism. We’re also working with other people in need such as low-income school kids, veterans, domestic violence survivors so we can serve the whole family. Pokket is designed to straddle the gaps between justice agencies and health and human services agencies, helping them support individuals both in custody and out-of-custody or individuals enrolled in adult/youth diversion programs.

## Company size

0-20

## Remote status

All the developers are remote. We also have an office in downtown Atlanta that everyone is welcome to use when they're in the city.

## Region

USA

## Company technologies

React, Node.js, GraphQL, AWS - Lambda, RDS, DynamoDB and other services

## Office locations

Atlanta, GA, USA

## How to apply

Check our jobs page at https://acivilate.com/jobs.html


