# 1Password

## Company blurb

1Password is a password manager that keeps you safe online. It stores all your personal information — passwords, credit cards, and more. We're always looking for new people as our team grows, and it's growing fast!

## Company size

200+ (as of January 2020)

## Remote status

Almost all of us are remote. We also have an office in downtown Toronto that everyone is welcome to use when they're in the city, but even Toronto locals pop in just a few days a week.

## Region

Current openings are for remote positions in US, UK, and Canada.

## Company technologies

Go, Rust, React, TypeScript, Swift, Kubernetes, and many others depending on the team.

## Office locations

Toronto, Ontario

## How to apply

Check our jobs page: https://1password.com/jobs/
