# FlowPath

## Company blurb

We’re a fully-remote company with no physical headquarters. We’re collectively spread out across the US, with most in Georgia. FlowPath is a Powerful all-in-one facilities, operations, and maintenance management platform with the most robust AI capabilities on the market. Designed to get more done by maintenance leaders across education, government, hospitality, and retail.

## Company size

more than 10

## Remote status

Full remote company.

## Region

United States

## Company technologies

 Ruby, React, Web 

## Office locations

Atlanta - Atlanta Tech Village

## How to apply

https://www.flowpath.com

https://www.getflowpath.com
