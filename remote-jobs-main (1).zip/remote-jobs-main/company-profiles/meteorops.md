# MeteorOps

## Company blurb

[MeteorOps](https://meteorops.com/about) is the all-in-one DevOps services company.  

## Company size

10-50

## Remote status

Fully remote, flexible timezone, flexible work hours.

## Region

* Worlwide

## Company technologies

Different with each client, but mostly the following tools and platforms:  
AWS, GCP, Terraform, Pulumi, Kubernetes, Prometheus, Docker, Python, NodeJS, Linux, Ansible, Jenkins, Helm.

## Office locations

Tel-Aviv, Israel

## How to apply

Check out our [careers page](https://meteorops.com/careers) for applying and getting information about what it is like to work at [MeteorOps](https://meteorops.com).
 
