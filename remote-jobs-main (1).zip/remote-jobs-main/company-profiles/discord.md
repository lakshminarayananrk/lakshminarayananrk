# Discord

## Company blurb

Discord is about giving people the power to create space to find belonging in their lives. We want to make it easier for you to talk regularly with the people you care about. We want you to build genuine relationships with your friends and communities close to home or around the world. Original, reliable, playful, and relatable. These are the values that connect our users and our employees at Discord.

## Company size

400-500.

## Remote status

Some jobs are remote optional.

## Region

USA

## Company technologies

* Rust
* Python
* Airflow
* React
* React Native

## Office locations

* San Francisco

## How to apply

* [Job Openings](https://discord.com/jobs)
