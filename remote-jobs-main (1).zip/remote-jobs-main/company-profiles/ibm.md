# IBM

## Company blurb

International Business Machines Corporation is an American multinational technology corporation headquartered in Armonk,
New York, with operations in over 171 countries.

## Company size

Over 280,000

## Remote status

Fully remote at the moment

## Region

Worldwide

## Company technologies

C++, C#, Java, .NET, React, Angular, Vue, Typescript, Swift, Salesforce

## Office locations

Worldwide locations

## How to apply

Find jobs: [careers website](https://www.ibm.com/employment/?lnk=fab#jobs).
