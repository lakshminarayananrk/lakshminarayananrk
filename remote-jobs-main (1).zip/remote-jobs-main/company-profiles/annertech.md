# Annertech

## Company blurb

Annertech is an Irish digital agency based in Dublin that is delivering ambitious digital experiences and work for digital transformation projects. 

## Company size

Between 50-250 employees

## Remote status

They have Remote working positions worldwide all the time

## Company technologies

PHP, Drupal, JavaScript, jQuery, Twig, Drupal Commerce, Platform.sh, Docker, Docksal, Apache, Solr, MySQL, MariaDB, Gitlab, Rest APIs

## Office locations

Dublin, Ireland and completely remote positions

## How to apply

[Annertech Careers](https://www.annertech.com/careers)
