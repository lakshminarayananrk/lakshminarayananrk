# MetaLab

## Company blurb

MetaLab is an interface design firm headquartered in Victoria, British Columbia that provides product design, engineering, and research services. MetaLab has a distributed team working from over a dozen different countries and serving clients all around the world. Their clients include Slack, Google, Uber, Amazon, other Fortune 500 businesses and startups.

## Remote status

We hire based on talent, not time zone, so your schedule is up to you. As long as you respect the team and deliver great work, we don't care how, where, or when you get it done.

## How to apply
[Metalab Careers](https://www.metalab.co/careers)

