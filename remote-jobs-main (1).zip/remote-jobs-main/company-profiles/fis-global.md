# FIS GLOBAL

## Company blurb

FIS is a leader in technology and services that helps businesses and communities thrive by advancing commerce and the financial world.

## Company size

65000+

## Remote status

100% remote from COVID. 

## Office locations

USA, UK, Asia

## Company technologies

 HTML/ CSS / Javascript / Typescript / React.js / Node.js / C# / .net / JAVA

## How to apply

[FIS global Careers](https://careers.fisglobal.com/)
