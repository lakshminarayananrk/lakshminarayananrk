# ExportData

## Company blurb

[ExportData](https://www.exportdata.io/) is a Twitter data export & analysis tool. It is already trusted by over 3,000 organizations & marketers. We handle massive amount of data (200M+ Twitter profiles) and are expanding to influencer search, tweet monitoring and analytics.

## Company size

3 (as of May 2021).

## Remote status

We are a remote first company. We are big fans of Notion, Slack, Github, Zoom and async communication in general.

## Region

Worldwide.

## Company technologies

Ruby, Ruby on Rails, Sidekiq + Redis, PostgreSQL, ElasticSearch, React.JS, Ghost, Terraform, Docker, AWS.

## Office locations

None, 100% remote.

## How to apply

You can view our open positions on [Exportdata team](https://www.exportdata.io/team) page.
