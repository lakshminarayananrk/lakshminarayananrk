# Ad Hoc

## Company blurb

Ad Hoc brings small teams of highly skilled professionals from the private sector to build government software right the first time.

## Company size

500 employees

## Remote status

We are proudly a remote-first company! We do have a few roles that require the ability to commute to client sites and those jobs are clearly delineated on our join page.

## Region

USA only for the time being: many of our contracts with the US government require employees to be in the US.

## Company technologies

- Ruby
- JavaScript
- Golang
- HTML
- CSS

## Office locations

None! We have a small co-working space for our DC team, but otherwise everyone works remotely.

## How to apply

Visit [Our join page](https://adhocteam.us/join/)
