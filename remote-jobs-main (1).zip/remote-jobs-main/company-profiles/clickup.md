# ClickUp

## Company blurb

ClickUp is one app to replace them all. It's the future of work. More than just task management - ClickUp offers docs, reminders, goals, calendars, and even an inbox. Fully customizable, ClickUp works for every type of team, so all teams can use the same app to plan, organize, and collaborate. ClickUp is trusted by millions of users and over 100,000 teams at the world's best companies like Google, Airbnb, Uber, and Nike.

## Company size

929 employees on LinkedIn.

## Remote status

The entire team works remotely.

## Region

Worldwide

## Company technologies

ClickUp uses 55 technology products and services including HTML5, Google Analytics, and jQuery, according to G2 Stack.
ClickUp is actively using 69 technologies for its website, according to BuiltWith. These include Viewport Meta, IPhone / Mobile Compatible, and LetsEncrypt.
## Office locations

Headquarters- San Diego.

## How to apply
[Click here to apply](https://clickup.com/careers)
