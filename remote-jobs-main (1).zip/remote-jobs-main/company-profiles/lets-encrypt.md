# Let's Encrypt

## Company blurb

Let’s Encrypt is a free, automated, and open certificate authority brought to you by the Internet Security Research Group (ISRG). ISRG is a California public benefit corporation, and is recognized by the IRS as a tax-exempt organization under Section 501(c)(3) of the Internal Revenue Code.

## How to apply

[Let's Encrypt](https://letsencrypt.org/jobs/)
