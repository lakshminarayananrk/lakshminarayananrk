# Epilocal

## Company blurb

Epilocal builds affordable digital tools for local news and other small and independent publishers.

We are developing a platform that brings the latest in open-source publishing and cloud architecture to local news companies, which will help them reduce costs while providing a modern, digital experience.  We also develop themes, plugins and integrations for a wide range of small publications.

## Company size

1-10

## Remote status

The team is currently fully remote, with the founder in Greece and freelancers worldwide.
We are planning on hiring more people in Europe in mid to late 2021.

## Region

Worldwide

## Company technologies

React, Gatsby, Node, AWS, Google App Script

## How to apply

Email info@epilocal.com or contact us at [https://www.epilocal.com/contact/](https://www.epilocal.com/contact/)
