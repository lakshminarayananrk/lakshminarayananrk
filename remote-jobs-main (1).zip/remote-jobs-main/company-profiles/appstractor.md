# Appstractor

## Company blurb

Reliable Data Solutions For The Digital Marketing Industries
Innovative technology for complex marketing problems.
Appstractor Corporation is the home for next generation Business Intelligence, Search and Inbound Marketing tools. Our team of talented people in six countries specializes in building tech solutions for the trickiest marketing problems.

## Remote status

Employees remote across six countries.

## Region

Worldwide

## Company technologies

LAMP

## Office locations

US, UK, Israel offices

## How to apply

Appstractor [careers](https://www.appstractor.com/careers/)
