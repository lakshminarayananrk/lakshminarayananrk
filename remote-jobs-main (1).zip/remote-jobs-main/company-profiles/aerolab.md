# Aerolab

## Company blurb

We’re a team of quirky yet lovable UX Wizards and Tech Geniuses. We create websites and apps, provide digital branding services and a consulting service to help customers define their product, strategy and roadmap from a user perspective.

## Company size

20-50

## Remote status

Work from home options available.

## Region

Latin America

## Company technologies

Development: JavaScript, using ES7, React, Node.JS
Design: Sketch, InVision, Marvel

## Office locations

Buenos Aires, Argentina

## How to apply

http://careers.aerolab.co/
