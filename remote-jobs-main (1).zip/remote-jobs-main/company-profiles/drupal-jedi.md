# Drupal Jedi

## Company blurb

Drupal Jedi is a leading agency with the focus on building advanced web apps.
We are always looking for the best solution and encourage to use the right technology for the right task.
Therefore a mix of Drupal with modern JS frameworks is our preferred setup.

## Company size

65


## Remote status

We are expanding our team and looking for talented people all over the world.

## Region

Worldwide.

## Company technologies

Backend: Drupal, Go, NodeJS.<br>
Frontend: React, Angular, VueJS.<br>
DevOps: k8s, docker

## How to apply

Learn for details on our Careers page - https://drupaljedi.com/careers
