#  Atlassian

  

##  Company blurb

  

Over 200,000 people trust Atlassian.

Behind every great human achievement, there is a team.
From medicine and space travel to disaster response and pizza deliveries, our products help teams all over the planet advance humanity through the power of software.

Our mission is to help unleash the potential of every team.

  

##  Company size

  

15,372 employees on LinkedIn

  

##  Remote status

  

Because we work in a remote environment, we happily hire people from all over the world who share our mission of making sending money as easy as sending a text.

  

##  Region

  
US, Europe, Asia, and Australia

  

##  Company technologies

  
Atlassian is a provider of collaboration, development, and issue tracking software for teams. With over 50,000 global customers (including 85 of the Fortune 100), their advancing the power of collaboration with products including JIRA, Confluence, HipChat, and Bitbucket.

  

##  Office locations

  

 - Sydney, Australia  
 - Bangalore, India
 - San Fransico, USA
 - Boston, USA

  

##  How to apply

  

[Click Here to apply](https://www.atlassian.com/company/careers)
