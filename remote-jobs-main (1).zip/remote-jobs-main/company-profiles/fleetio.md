# fleetio

## Company blurb

Fleetio is a modern software platform that helps thousands of organizations worldwide manage their fleets. You can learn more about our platform here. Transportation technology is a hot market and we're leading the charge, with raving fans and new customers signing up daily. We raised a $21M Series B in late 2020 and are on an exciting trajectory as a company.s

## Company size

51 - 250

## Remote status

100% Remote. Work from anywhere.

## Region

Worldwide

## Company technologies

AWS, Terraform, Vault, Consul, Packer, Nomad, Boundary, K8s, Go, Python,Nodejs


## How to apply

You can contact us through the (https://www.fleetio.com/careers) on the website
