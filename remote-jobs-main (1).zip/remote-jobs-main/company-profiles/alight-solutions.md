# Alight Solutions

## Company blurb

Alight Solutions is a provider of benefits administration and cloud-based HR and financial solutions, we enhance work and life through our service, technology and data.  Alight Solutions is reimagining how people and organizations thrive so clients and their people are free to enjoy more in work and in life. 

## Company size

An approximate size of your Alight Solutions is between 20,000 - 22,000 across the globe from United States to India and more.

## Remote status

They offer on location positions as well as remote positions.

## Region

United States, India, Poland, and more

## Company technologies

Python, Ruby, .NET, MSSQL

## Office locations

Headquarters: Lincolnshire, Illinois

## How to apply

Please apply at the career portal [Alight Solutions Careers](https://careers.alight.com)
