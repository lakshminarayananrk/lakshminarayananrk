# Civo

## Company blurb

Civo’s vision is simple. To create a flexible cloud platform created by developers, for developers. We think you should spend less of your time managing environments and hosting platforms, and more time coding – after all, that’s what we always wanted.

## Company size

11-50 

## Remote status
Our team is truly global. We're just as at home working remotely as we are from at our office HQ in Stevenage, UK

## Region

 Worldwide

## Company technologies

- OpenStack
- Cloud
- Ruby on Rails
- Go
- Web Design
- Kubernetes 
- k3s

## Office locations

- Stevenage, Hertfordshire

## How to apply

[Civo careers page](https://www.civo.com/careers)
