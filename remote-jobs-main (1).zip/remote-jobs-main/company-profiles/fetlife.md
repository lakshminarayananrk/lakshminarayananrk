# Fetlife

## Company blurb

FetLife is a social networking website that serves people interested in BDSM, fetishism, and kink. On its homepage, FetLife describes itself as, "Like Facebook, but run by kinksters like you and me." FetLife distinguishes itself from competitors by emphasizing itself as a social network rather than a dating site.

- Largest kinky social network this side of the Milky Way
- Over 6 million members and growing every day
- Grew 100% by word-of-mouth
- Serve a couple of billion requests a month
- Top 600 website in most English speaking countries

## Company size

Between 11-50 employees


## Remote status
Completely Remote


## Company technologies

Ruby on Rails, JavaScript, jquery, Webpack, Babel, Mousetrap, Google Cloud DNS, Postmark, Varnish, nginx, Amazon S3 CDN, 

## Office locations
Completely Remote

## How to apply

[Fetlife Jobs](https://remoteok.io/remote-companies/fetlife)
