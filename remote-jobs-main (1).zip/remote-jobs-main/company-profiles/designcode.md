# Designcode

## Company blurb

This company offers various courses and prepares you to further jobs.

## Company size

An approximate size of company 50-100.

## Remote status

We employ several strategies to ensure an inclusive and collaborative environment for all our employees.
At least once a year we organize an in-person all-hands team week. It’s the best.


## Region

Worldwide


## Company technologies

Node.js
React
WebRTC
Pug
Stylus

## Office locations
We receive post at Egerlandstrasse 9, 71236 Weil der Stadt, Germany

## How to apply

No openings currently 
