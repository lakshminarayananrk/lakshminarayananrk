# Close

## Company blurb

Sales/CRM tool with great calling and email integration

## Company size

20-50

## Remote status

All remote

## Region

Open to worldwide employees provided that they can do some timezone
overlap with US business hours.

## Company technologies

Python / Flask, JavaScript / React, HTML5 / CSS, MongoDB, Elasticsearch, Postgres, AWS, Terraform, Docker, Kubernetes

## Office locations

None

## How to apply

[http://jobs.close.com](http://jobs.close.com)
