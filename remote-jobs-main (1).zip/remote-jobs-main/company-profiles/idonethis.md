# IDoneThis

## Company blurb

[I Done This](http://idonethis.com) is the easiest way to share and celebrate what you get done at work, every day, that companies like Zappos, Foursquare, and Reddit use. 
It's that simple. No hassle, no micromanagement. Get stuff done, and celebrate it with your team.

## Company size

2-10 employees

## Region

Worldwide

## Company technologies

productivity, management, reporting, fulfillment, performance management, coaching, employee recognition, leadership, social performance, status reports, snippets, enterprise, business software, and enterprise social software 

## Office locations

San Francisco, CA 

## How to apply

[IDoneThis](http://idonethis.com)

[LinkedIn](https://www.linkedin.com/company/idonethis/)
