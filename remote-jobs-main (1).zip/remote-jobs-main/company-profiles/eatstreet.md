# EatStreet

## Company blurb

EatStreet is a food delivery platform and service mostly based in the American Midwest. Focusing on providing customers fast and easy food delivery option. 

"EatStreet hustles to hook up people's hungry and we want you to join our tight-knit team of innovators that's been named as one of Madison Magazine's Best Places to Work."

## Company size

500 - 1000

## Remote status

Work from most states in the US. Fully remote for tech, HR, and most other business positions with the option to go in office if you wanted. Drivers and Food personel do have to work at designated locations.

## Region

USA

## Company technologies

JavaScript, Ruby on Rails, Angular, AWS, Java, Ionic Framework.

## Office locations

Madison, WI, USA

## How to apply

EatStreet's [Career Page](https://eatstreet.com/careers)