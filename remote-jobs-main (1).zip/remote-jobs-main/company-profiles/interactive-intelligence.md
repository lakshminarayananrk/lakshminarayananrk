# Interactive Intelligence

## Company blurb

Interactive Intelligence provides software and cloud services for customer engagement, unified communications and collaboration to help businesses worldwide improve service, grow their business faster and reduce costs.

## Company size

2000+

## Remote status

We don't typically hire remotes. Usually people whom have worked with the company and moved afterwards.

## Region

Remotes are preferred to be on New York time or similar, as our main offices are on New York time, but there are various remotes throughout the globe.

## Office locations

Main developer locations: Indianapolis, IN; Raleigh, NC;
We also have other various worldwide business office locations.

## How to apply

https://www.inin.com/careers
