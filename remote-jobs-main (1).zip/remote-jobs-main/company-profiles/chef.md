# Chef

## Company blurb

We are Chef. We are IT automation for speed and awesomeness. We give you a model for automating IT infrastructure and applications that drive self-reliance across your development and operations teams. We are the Chef Community. We are tens of thousands strong. We are helping your businesses become faster, safer and more flexible, so you win in today's 24x7 digital economy. Join our movement today.

## Remote status

We're based in Seattle, WA but have employees from coast to coast.

## Region

Mainly USA but some UK

## Company technologies

Chef

## Office locations

Chef Seattle
619 Western Ave, Suite 400
Seattle, WA 98104

Chef San Francisco
48 2nd St., 4th Floor
San Francisco, CA 94105

## How to apply

[Chef careers](https://www.chef.io/careers/)
