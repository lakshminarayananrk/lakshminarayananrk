# Algorand

## Company blurb

Algorand is a scalable, secure and decentralized digital currency and transactions platform.

## Company size

51-100

## Remote status

Remote USA or Boston, MA

## Region

USA

## Company technologies

Go, Java, C/C++, C#, Rust, WebSockets, Google Workspace, AWS, Slack, Microsoft 365, FreshService, HubSpot

## Office locations

Boston, MA

## How to apply

https://www.algorand.com/about/careers/our-jobs
