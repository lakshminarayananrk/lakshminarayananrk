# Konkurenta

## Company blurb

Konkurenta is the best way to learn and use the newest technologies in exiting projects. Currently, we focus on fulfilling our clients needs, but in the near future we're going to work on our internal projects.

We're mainly located at the central-eastern part of EU, but have a developer from Brazil. So we're overlapping 6 hours.

Living in a place that makes you happy is one of our core beliefs.

## Company size

0-20

## Remote status

Konkurenta is a 100% remote company, fully encourages remote friendly work. 
Also, we also have a tiny office in Vilnius for personal work preference.

## Region

Mainly EU, we have one developer from Brazil.

## Company technologies

Javascript, React, React Native, Graphql, WebRTC, Node.js, RabbitMQ, MongoDB, MySQL, Redis

## Office locations

Vilnius

## How to apply

Look for open positions, or introduce yourself 🙌 

[Konkurenta's jobs](https://konkurenta.com/jobs)

Or contact us directly: jobs@konkurenta.com with subject: "Github remote jobs"
