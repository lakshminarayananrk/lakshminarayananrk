# LogRocket

## Company blurb

LogRocket helps you understand problems affecting your users, so that you can get back to building great software.

## Company size

500+

## Remote status

Remote - US (depends on the position).

## Region

USA

## Company technologies

JavaScript, React Native

## Office locations

US, Boston

## How to apply

https://logrocket.com/careers
