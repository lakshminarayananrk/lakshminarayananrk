# Coingape

## Company blurb

Coingape is a indian Crypto Media company which provides instant news of the crypto industry as ssoon as possible to people.

## Company size

0-50 Employees

## Region

**India** 

## Office locations

ACI Co-work, Gold Souk, Mall, Sec-43, Block C, Sushant Lok Phase I, Sector 43, Gurugram, Haryana 122002

## How to apply

Coingape lists all it's available positions on it's careers page, [here](https://coingape.com/careers/).
