# earthofdrones
## Company blurb

We are a small team of highly skilled developers working on a Earth of  Drones platform. We supply all need information about drone flies. Drone laws and regulations in different countries. 

Articles about different Drone shooting techniques and many tips for get better skills for flying and photo shoot. Advises for post-production and drones reviews. 


Learn more about us at https://www.earthofdrones.com

## Company size

Approximately 5+ employees split between our SF offices and many remote employees across the globe.

## Remote status

Remote friendly!

You're expected to maintain a regular day-to-day schedule and be in the 'office' & responsive during your chosen work time.  That said, we offer lots of flexibility for adjusting your schedule based on personal/family needs. 



## Office locations

San Francisco, USA

## How to apply

https://www.earthofdrones.com
