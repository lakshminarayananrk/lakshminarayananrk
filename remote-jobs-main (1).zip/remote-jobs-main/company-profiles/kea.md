# kea


## Company blurb

kea builds conversational AI for restaurants. 

## Company size

20-50

## Remote status

Fully-remote. Must be in North or Latin America. 

## Region

North and Latin America

## Company technologies

JavaScript / AWS / PostGreSQL / Mocha / Python / Cypress / Chai / Twilio / Docker

## Office locations

California, USA

## How to apply

[Apply Here](https://careers.kea.ai)!
