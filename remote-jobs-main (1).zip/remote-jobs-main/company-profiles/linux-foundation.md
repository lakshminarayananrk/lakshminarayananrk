# Linux Foundation

## Company blurb

The Linux Foundation is the organization of choice for the world's top developers and companies to build ecosystems that accelerate open technology development and commercial adoption. Together with the worldwide open source community, it is solving the hardest technology problems by creating the largest shared technology investment in history. Founded in 2000, The Linux Foundation today provides tools, training and events to scale any open source project, which together deliver an economic impact not achievable by any one company.

## Company size

51 - 300 people.

## Remote status

Remote and Office.

## Region

**Worldwide**.

## Company technologies

- Go
- Docker
- C, C++
- Bash
- Etc Open Source Project

## Office locations

1 Letterman Drive, San Francisco, CA 94129, US.

## How to apply

We are hiring! visit https://www.linuxfoundation.org/about/careers/
