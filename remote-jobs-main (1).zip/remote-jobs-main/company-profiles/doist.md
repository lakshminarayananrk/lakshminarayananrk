# Doist

## Company blurb

At Doist, we specialize in productivity software.

We create tools like Todoist and Todoist Business that simplify and organize the day. When software tames the chaos and streamlines the little things, it frees you to focus on the big things. 

We’re a chiefly remote team from all around the world, and our mission is to help people do more each day so they can make the most of their potential.

## Company size

50 people in 25 countries

## Remote status

Fully remote

## Region

Worldwide

## Company technologies

Android, iOS/OS X, Windows, Python, Django, Ruby on Rails, Javascript, HTML, CSS, CoffeeScript, React, MYSQL, Redis, GIT, Wordpress, C#, C++

## Office locations

R&D office in Porto, Portugal

## How to apply

Check out our [careers page](https://doist.com/jobs/).
