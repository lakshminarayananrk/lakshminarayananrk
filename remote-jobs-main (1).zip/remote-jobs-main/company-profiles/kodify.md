# Kodify

## Company blurb

Company that works on adult entertainment, tube sites and subscription sites

## Company size

20-50 people

## Remote status

You can work pretty much from everywhere as long as you have some overlap with
our core hours (11 to 17 Spanish time)

## Region

Company is based in Barcelona, Spain but you can work from everywhere

## Company technologies

NodeJS and JS. Not sure about the db's

## Office locations

Barcelona, Spain

## How to apply

Mail to careers@kodify.io or apply on [linkedin](https://www.linkedin.com/jobs/search?f_C=2771097&locationType=Y&trk=careers_promo_module_see_jobs)
