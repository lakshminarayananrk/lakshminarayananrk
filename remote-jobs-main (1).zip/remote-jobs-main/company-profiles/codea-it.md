# Codea IT

## Company blurb

We are a company that provides a full range of services and products within the IT industry.

We focus on custom development: corporate solutions, mobile, web and desktop applications. In our wide range of services we maintain high quality standards, adding real value and derencial in our daily work.

Our focus is on strategically assist our clients in achieving their business goals through the right combination of knowledge and ability.

## Company size

~10

## Remote status

The team is remote across most functions within the company.

## Region

Worldwide

## Company technologies

AngularJS, Node.js, Android (Java), iOS (Objective-c, Swift), HTML5, CSS, JavaScript, PHP, Ruby, React, Wordpress, C#, Sails.js, Python, .NET, MongoDB, Postgres, SQL 

## Office locations

Buenos Aires, Argentina

## How to apply

[Contact us](http://www.codeait.com)
