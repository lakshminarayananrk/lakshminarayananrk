# LionSher

## Company blurb

We help customers showcase and sell their work online. Our products are used on over 1.5M+ websites and are the highest rated in the market.

## Company size

11-50

## Remote status

We are a 100% remote company. You can choose to work from home or anywhere that has internet. We value people that are self-motivated to produce results without someone looking over their shoulder.

## Region

**Worldwide**

## Company technologies

WordPress, PHP, HTML, CSS, Javascript, Zenhub, Kubernetes

## Office locations

N/A

## How to apply

https://lionsher.com/careers/
