# Marco Polo

## Company blurb

Marco Polo is a popular video communication app that makes being a part of anyone's day effortless, even when life gets busy. Marco Polo helps millions of people stay in touch with their real relationships.

Since our founding in 2016, our Marco Polo community has sent more than 4 billion Polos. As we grow our team, we’re looking for great people who want to make a difference in the lives of people around the world!

## Company size

20-50 (as of August 2021)

## Remote status

We are fully remote and spread throughout the US and Canada. We try to get together for an offsite a couple of times per year.

## Region

North America

## Company technologies

Python, Java, Kotlin, Swift, Objective-C, Firebase, Vue.js

## Office locations

N/A - fully remote

## How to apply

Check out our jobs page at: https://marcopolo.me/jobs
