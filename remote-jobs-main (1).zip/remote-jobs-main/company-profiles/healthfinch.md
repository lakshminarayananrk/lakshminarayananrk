# Healthfinch

## Company blurb

Healthfinch consists of a team of bright, motivated people with the goal of helping health care systems reach peak efficiency.

We aim to help physicians direct as much focus as possible towards their patients by automating whatever possible, such as prescription refill management and visit planning.

## Remote status

Employees are encouraged to work remotely wherever they feel most comfortable and productive.  If one person is remote, we are all remote. 

## Region

USA

## Company technologies

TypeScript, JavaScript, Angular, NodeJS, C#, CSS3, HTML5, Elasticsearch, MS SQL

Ruby, Ruby on Rails

SQL

Clojure, React, RSpec, AWS

## Office locations

Madison, WI, USA

## How to apply

Career information can be found on our [careers page](https://www.healthfinch.com/careers).