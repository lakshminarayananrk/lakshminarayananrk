# AIM India

## Company blurb

AIM India believes in Dynamic Culture and it is our goal to help the Individual in dealing with the dynamism of environment whether it is related to their wealth or expansion of business. Aim India Group is the leading Advisory in India and Abroad. We at AIM India provide Training / Development programs in India and Abroad .We are having a team of exclusive Corporate trainers .Our Principle is to deliver high rate of returns to our clients through our network of government sector banks in India.

Keeping in mind the most critical needs in today's context, we came up with wealth Advisory firm to provide a customer expertise advice to achieve financial Independence.

## Company size

11-50 employees (as of October 2022)

## Remote status

Almost all of us are remote. We also have an office in India (New Delhi, Bengaluru, Mumbai, Pune, Hyderabad, Gurugram) that everyone is welcome to use when they're in the city, but even India locals pop in just a few days a week.

## Region

Current openings are for remote positions in Malaysia, Dubai.

## Company technologies

Excel, Artificial Intelligence (AI) , Machine Learning (ML) and many others depending on the team.

## Office locations

India

## How to apply

Check our jobs page: https://www.aimincorp.com/carrers.php/
