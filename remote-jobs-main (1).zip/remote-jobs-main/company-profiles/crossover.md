# Crossover 

## Company blurb

Crossover connects talent from around the globe with companies that are looking to hire only the best. We have more than 3500 partners from 116 different countries working full time (40 hrs/wk) for our clients. Our clients are Fortune 1000 companies that have challenging problems to solve. Some of our clients include Aurea, Mobi, Ignite, Upland, 3Seventy, Dispatchr, POPinNow, Versata, RealStarter.co, webElect.net, and DevFactory.

## Remote status
100% global team working remotely from anywhere

## Company size
4,000+ team members in 131 countries

## Region
Worlwide

## Office locations
Austin,Texas, USA

## How to apply
Apply Here - [ Jobs ](https://www.crossover.com/jobs)
