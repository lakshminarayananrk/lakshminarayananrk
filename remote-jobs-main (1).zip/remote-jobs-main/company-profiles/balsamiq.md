# Balsamiq

## Company blurb

Balsamiq makes rapid wireframing software that combines the simplicity of paper sketching with the power of a digital tool so that teams can focus on what's important. Balsamiq is a small and personable company that competes on usability and customer service. Balsamiq believes work should be fun, and that life is too short for bad software. ([read more on our company page](https://balsamiq.com/company/))

## Company size

20-50

## Remote status

Balsamiq is optimized for working remotely. This means that even the employees who work in our office in Italy work as if they were remote. All communication and meetings are done using connected digital tools, for example. 

## Region

We currently have employees in the U.S. and in several European countries.

## Office locations

We have one office in Bologna, Italy. All other employees work from home.

## How to apply

[Balsamiq jobs page](https://balsamiq.com/company/jobs/)
