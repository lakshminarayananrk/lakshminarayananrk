# CoreOS

## Company blurb

CoreOS builds industry-leading infrastructure software to securely run application containers anywhere. 

## Company size

An approximate size of CoreOS is between 51 - 100.

## Remote status

No current job openings on their website.

## Region

United States.

## Company technologies

Linux (based on Gentoo Linux)

## Office locations

Headquarters: 
101 New Montgomery
San Francisco, CA 94105
United States

## How to apply

Please visit their website for job openings [CoreOS](https://coreos.com/).
