# Cosmic Chimps

## Company blurb

Design strategies with Cloud and DevSecOps mainly for Startups companies.

## Remote status

You'll work 100% remotely independient of your location.

## Region

Spain and México

## Company technologies

- Java
- Flutter
- PHP
- Amazon Web Services
- Jira
- Git
- Docker
- Ansible

## Office locations

Pla de Pau Vila, Barcelona, Spain
Liverpool 174, Juárez, Cuahutemoc, CDMX, México

## How to apply

https://www.linkedin.com/company/cosmic-chimps/jobs/
