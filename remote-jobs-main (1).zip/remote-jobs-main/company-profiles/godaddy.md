# GoDaddy

## Company blurb

We’re the world’s largest web services platform. Our mission is to make opportunity more inclusive for all and fuel a new generation of entrepreneurial endeavors — commercial, civic, creative. Join our diverse collective of 9k+ employees across 47 global locations.

## Company size

10k - 50k

## Remote status

We're chatting with candidates remotely, and we're super flexible around schedules, kids and dogs. Our onboarding has gone remote, too.

## Region

Worldwide

## Company technologies

AWS , Java , Javascript , PHP , GO .

## Office locations

Godaddy.com LLC, 14455 N Hayden Rd, Scottsdale, AZ, Information Technology Services , Tempe , Arizona , United States.

## How to apply

Check our jobs page: https://careers.godaddy.com/
