# Gojob

## Company blurb

We are the first digital temping agency in France. We connect 700 clients and 80000 temporary workers around France. Created 5 years ago, we have the social purpose to hack unemployment.

To reach this goal, we are a team of 18 tech lovers working continuously on the improvement of the Gojob's applications. 

## Company size

90-100

## Remote status

Our team is divided between full remote and no-remote developers.

Some of us work in the Aix-en-provence offices, and some of us, from anywhere they see fit to (within France). We refund lodging and transport fees in case you need to be present in the office for a special event.

## Region

France

## Company technologies

- React.js
- Nest.js
- Typescript
- GraphQL
- MongoDB


## Office locations

Aix-en-Provence, France.

## How to apply

You want to work with us?

Go to our Careers page on [welcometothejungle.co](https://www.welcometothejungle.com/fr/companies/gojob) and fill out the form on the particular job.


