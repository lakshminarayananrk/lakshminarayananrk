# Jobsity

## Company blurb

Josity is a Nearshore which provides augmentation staff to companies in the USA

## Company size

200+ (as of October 2022)

## Remote status

Almost all of us are remote. We also have an office in Quito Ecudor, Colombia and New York City that everyone is welcome to use when they're in the city, but even Quito locals pop in just a few days a week.

## Region

Current openings are for remote positions in US and LATAM.

## Company technologies

Go, Rust, React, TypeScript, Swift, Kubernetes, and many others depending on the client.

## Office locations

Quito, Colombia, New York

## How to apply

Check our jobs page: https://recruitment.jobsity.com/applylp
