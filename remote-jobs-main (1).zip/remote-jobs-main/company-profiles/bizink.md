# Bizink

## Company blurb

Bizink makes accountants and bookkeepers incredible online with websites, content and online marketing designed to help accountants win more business, engage with more clients and save more time.

## Company size

0-20

## Remote status

100% remote.

## Region

**Worldwide**

## Company technologies

* Wordpress
* HTML
* CSS

## Office locations

Wanaka, Otago, NZ.

## How to apply

See [this](https://bizinkonline.com/careers/) page for job postings (none available currently).