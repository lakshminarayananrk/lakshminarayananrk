# Cuvette

## Company blurb

Cuvette (pronounced as Q-vet) is the #1 way for College students & Early Graduates to get ... Tech. Management. Media. Additional Skills. Software.

## Company size

 2-10 employees

## Remote status

Yes

## Region

Worldwide! We have or have had people based in India

## Company technologies

* Javascript
* Git
* CSS
* HTML

## Office locations

Bengaluru, Karnataka

## How to apply

Check out our [careers](https://cuvette.tech/app/student/login?type=register) page, or just reach out!
