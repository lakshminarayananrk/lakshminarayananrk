# Cyber Whale

## Company blurb

SaaS Solutions for Fintech and e-commerce.
We value quality, responsibility and holistic approach to creating products.

## Company size

15+

## Remote status
Based in Republic of Moldova, hiring remotely in EU, Eastern Europe, working with customers from US, UK, EU, Israel.
We quickly integrate colleagues who are on remote.

## Region

Europe

## Company technologies

Python
PostgreSQL
JS
TS
React
Vue
Angular
nx.dev
Java
C#.NET

## Office locations

str 31 August 78 iHub Green, Chisinau, Republic of Moldova

## How to apply

[https://weloveremotejobs.com/employer/cyber-whale/](https://weloveremotejobs.com/employer/cyber-whale/)
