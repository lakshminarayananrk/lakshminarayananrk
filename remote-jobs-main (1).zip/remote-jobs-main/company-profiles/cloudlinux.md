# CloudLinux

## Company blurb
CloudLinux is the only commercially supported operating system (OS) optimized for hosting service providers who manage a significant level of shared hosting accounts and for datacenters who sell servers to enterprise and SMB customers. 

## Company size
51-200 employees

## Remote status
Flexible Work Environment, as Fully Remote.
We don’t look at when you log in, log out or how much time you work. We trust you, it’s the only way remote can actually work.

## Company technologies
CloudLinux OS provides a modified kernel based on the OpenVZ kernel

## Office locations
- US

## How to apply
Check out our [careers page](https://www.cloudlinux.com/about-us-company-jobs/) for information about what it is like to work at CloudLinux.
