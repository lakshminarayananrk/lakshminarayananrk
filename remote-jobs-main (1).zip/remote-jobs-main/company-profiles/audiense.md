# Audiense

## Company blurb

Audiense enables innovative organizations to understand and apply the power of audience segmentation and insights by reinventing the use of compliant social data to make it more strategic and connect it with the business/marketing strategy to be relevant and deliver results. Audiense is used to find and understand large or very specific audiences perfectly matched to your product or brand and discover what an audience talk about, their affinities, as well as how they think, behave and define themselves.
## Company size

51-200 employees

## Remote status

Employees can work from anywhere in the world and they offer flexible working hours.

## Region

Worldwide

## Company technologies

- Data Mining
- Segmentation
- Python
- Machine Learning
- Tableau


## Office locations

UK, US and Spain

## How to apply

[Audiense Careers](https://aboutus.audiense.com/careers)
