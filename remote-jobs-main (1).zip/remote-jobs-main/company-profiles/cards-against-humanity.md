# Cards Against Humanity

## Company blurb

Cards Against Humanity, LLC is a Chicago-based game design firm.

Following a successful Kickstarter project, their first product, Cards Against Humanity, became the top-selling game on Amazon.com and has sold out three printings.

## Company size

2-10

## Remote status

Cards Against Humanity, LLC is remote-friendly and occasionally offers work from home job opportunities.

## Region

USA

## Company technologies

jQuery, JavaScript, Python, NGINX, CSS 3

## Office locations

Chicago, Illinois

## How to apply

Job openings are [posted on the Careers page](https://www.cardsagainsthumanity.com/careers) and [will likely be advertised on their blog](https://cah.tumblr.com/). You can also email them at Mail@CardsAgainstHumanity.com.