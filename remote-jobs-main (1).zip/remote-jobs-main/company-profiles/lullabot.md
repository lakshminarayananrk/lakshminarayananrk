# Lullabot

## Company blurb

Lullabot is one of the top open source, interactive agencies in the world. We employ talented developers, designers, project managers, trainers, unicyclers, and more to make amazing websites, mobile apps and all manner of delightful tech.

## Company size

60+

## Remote status

At Lullabot our virtual employees are our physical employees. We do not have a central office we work from. We won’t put you on speakerphone and you won’t be the last to know when something important happens. In fact, we all use the same tools to communicate on a daily basis. Tools like Google Docs, Yammer, GitHub and even Drupal enable our conversations and our work to end up having a URL. These tools may change but the culture of inclusion and empowerment is key for a distributed team to have fun and be successful.

## Region

- 6 countries
- 52 cities

## Company technologies

- Drupal
- PHP
- HTML
- Sass
- CSS
- JavaScript
- Ruby
- Phone Gap
- Titanium

## Office locations

Completely distributed!

## How to apply

https://www.lullabot.com/jobs
