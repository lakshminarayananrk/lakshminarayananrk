# Best Practical Solutions

## Company blurb

Best Practical Solutions develops and maintains the open source ticketing software, Request Tracker (RT), and many of its extensions.

## Company size

0-20

## Remote status

Fully distributed team. Employees can work from anywhere worldwide.

## Region

Worldwide

## Company technologies

Perl, Mason, MySQL/PostgreSQL/Oracle, Linux based OS, JavaScript/jQuery, CSS

## Office locations

No physical location

## How to apply

Check for openings [here](https://bestpractical.com/jobs)

