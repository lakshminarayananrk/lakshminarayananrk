# Betable

## Company blurb
BETABLE PROVIDES THE ONLY FULL-STACK PLATFORM FOR FRICTIONLESS MARKET ENTRY AND THE CREATION, DISTRIBUTION AND CONSUMPTION OF GAMBLING ENTERTAINMENT.

Betable’s platform will become the rails for creating, distributing and consuming all real-money gambling games.

## Remote status
We have team-members in Edmonton, Manchester and San Francisco.

## Region
USA, Europe

## Office locations
* Edmonton, Canada
* San Francisco, California
* Manchester, England

## How to apply
Visit [Betable Careers page](https://corp.betable.com/careers) for information on how to apply.
