# Klanik

## Company blurb

Klanik IT Consulting, headquartered in Marseille, France. is a company that offers job in IT, tech or governance, many city and country, in remote or directly in company.

## Company size

+1500 (December 2023)

## Remote status

As a remote & in-place company since 2011, Klanik employs a virtual-first mindset.

## Region

Europe & USA

## Company technologies

- Agile
- Data & AI
- Cybersecurity
- DevOps & Cloud
- Software

## Office locations

Headquarters in Marseille with studios in France, Canada and Emirates.

## How to apply

Visit [Klanik's job page](https://www.klanik.com/en/jobs?) for open positions and to apply!
