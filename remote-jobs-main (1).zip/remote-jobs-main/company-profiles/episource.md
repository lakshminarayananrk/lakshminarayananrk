# Episource

## Company blurb

SIMPLIFYING HEALTHCARE - We are reinventing the way healthcare organizations manage their member populations through technology and innovation.

## Company size

500+ Employees

## Remote status

Remote-first engineering team distributed throughout USA.

## Region

USA

## Company technologies

ReactJS, NodeJS/TypeScript, Python, Scala, Golang, Kubernetes.

## Office locations

- Los Angeles, CA (Headquarters)
- Tampa Bay, FL

## How to apply

https://www.episource.com/careers/
