# Andela

## Company blurb

[Andela](https://andela.com) builds remote engineering teams with the world’s top talent. 

## Company size

+1000

## Remote status

Working remote is an option.

## Region

Worldwide.

## Company technologies

Java, React, Ruby, JavaScript, Python

## Office locations

New York, USA

## How to apply

[Join Andela](https://andela.com/join-andela/)
