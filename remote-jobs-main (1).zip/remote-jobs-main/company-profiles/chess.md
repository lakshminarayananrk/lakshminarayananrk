# Chess

## Company blurb

Chess.com is a global team of passionate chess fans and developers. You can meet us [here](https://www.chess.com/about) and read about our company [here](https://www.chess.com/article/view/how-chess-com-virtual-team-works-together). We're always looking for great people to join the team. We have a healthy work environment focused on well-being, respect, and memes/emotes. We communicate with Slack and positive energy beams.

## Remote status

All of our jobs are 100% remote.

## Region

Worldwide

## Company technologies

PHP, React, Node.js, Objective-C, Swift, Python

## Office locations

Orem, UT
Founded 2005
Video Game Publishing

## How to apply

[Chess jobs](https://www.chess.com/jobs/)
