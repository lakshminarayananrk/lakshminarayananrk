# Glenn Website Design

## Company blurb

Glenn is a custom web design company that offers full-service web solutions for many types of business profiles including hotels, restaurants, e commerce shopping websites, interactive websites.

## Company size
5 currently (12/5/2019) and growing

## Remote status
All of our company works remote. We communicate via email, messenger, and online chats

## Region

### Worldwide

## Company technologies

WordPress, HTML code, JavaScript, PHP, MySQL

## Office locations
Tulsa Oklahoma, Bandung Indonesia

## How to apply
Glenn Website Design [contact page](https://glennwebsitedesign.com/contact/)
