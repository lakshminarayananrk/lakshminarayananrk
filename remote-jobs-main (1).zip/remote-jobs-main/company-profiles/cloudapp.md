# CloudApp

## Company blurb
CloudApp uploads any of your captured content as a public or private shortlink URL that makes it easy to show your team, customers, or friends what you're trying to say.

Why Visual Communication?

Visual communication for every industry where speed and clarity are essential. 

Technology has changed the way we work, the way we live, the way we communicate. Always on and everywhere, it empowers us to be more connected than ever before. Productivity has increased, but also the need for a solution to cut through the noise and make communication faster, and more effective.

## Company size
0-25

## Remote status
The company has an office in the Greater San Francisco area as well as in Salt Lake City. Some employees work out of these locations, while the rest are remote located in various countries across the world. 

## Region
Worldwide.

## Company technologies
Ruby, rails, AWS, node, go, lambda, postgresql, redis

## Office locations
California & Utah

## How to apply
Check our jobs page: https://www.getcloudapp.com/careers
