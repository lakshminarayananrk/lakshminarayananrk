# Fly.io

## Company blurb

[Fly.io](https://fly.io/) is a platform for running full stack apps and databases close to your users (edge computing) all around the world.

## Company size

33 (as of October 2022)

## Remote status

Everyone is remote, but there is an office in Chicago for those who would like to use it.

## Region

Current openings are for remote positions anywhere in the world.

## Company technologies

Elixir, Rust and Ruby

## Office locations

Chicago, Illinois

## How to apply

Check the jobs page: [Jobs - Fly.io](https://fly.io/jobs/)
