# Buffer

## Company blurb

Buffer is the best way to drive traffic, increase fan engagement and save time on social media.

We're a fully distributed team, meaning that we'll be fixing bugs and replying to your questions from around the world!

The Buffer team works from multiple countries and continents. Living in a place that makes you happy is one of our core beliefs, and has stayed with the company since the beginning.

## Company size

50

## Remote status

Buffer is a 100% remote company and fully encourages remote friendly work.

## Region

Buffer employs people worldwide

## Company technologies

Redshift, Hadoop, MongoDB JavaScript, PHP, Underscore, Backbone.

## Office locations

No physical office, recently sold HQ and all employees work remotely.

## How to apply

The full story and roles overview is on the Buffer [Journey page](https://buffer.com/journey)
