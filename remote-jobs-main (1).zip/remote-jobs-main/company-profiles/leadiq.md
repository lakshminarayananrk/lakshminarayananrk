# LeadIQ

## Company blurb

LeadIQ was founded in 2015 with a mission to create a world where every professional has the capability and access to responsibly connect with others. Today we're a leader in sales technology with over 10,000 users ranging from Fortune 500 Companies to Unicorn startups.

The company was founded in 2015. For more information, please visit [leadiq.com](https://leadiq.com/).

## Company size

(as of October 2022)
180+ Teammates
20+ Nationalities

## Remote status

100% remote
Almost all of us are remote. We also have an office in San Francisco, California

## Region

Current openings are for remote positions in Worldwide.

## Company technologies

Vue.js, Javascript, Kubernetes.

## Office locations

548 Market Street,
PMB 20371,
San Francisco, California 94104, US

## How to apply

Check our jobs page: https://leadiq.com/careers
