# Appinio


## Company blurb

Appinio enables anyone to survey highly specific target groups. Conduct market research in hours rather than weeks and make better decisions using customer opinions.

## Company size

100 - 200

## Remote status

Need to be registered in Europe. Work remote anywhere in Europe (EU) or anywhere in the world for maximum 6 consecutive months (depends on each country's rules).

## Region

Europe

## Company technologies

Angular / Flutter / Node.js / MongoDB / AWS

## Office locations

Hamburg, Germany

## How to apply

[Apply Here](https://www.appinio.com/en/careers)!
