# eFishery

## Company blurb

Founded in 2013, eFishery is the first Aquaculture Technology startup in Asia that develops innovations in the aquaculture field. eFishery disrupts traditional fish farming methods and provides cutting edge solutions in the aquaculture ecosystem by offering an end-to-end platform that provides access to feed, financing, and market to fish and shrimp farmers. eFishery aims to build an aquaculture ecosystem in Indonesia that is not only profitable but also sustainable to the farmers, buyers, and to all stakeholders.

## Company size

1,100+ (As of September 2022)

## Remote status

Work from anywhere, you can choose to work wherever you like.

Work From Anywhere (WFA) is a concept that gives eFisherian the option to work anywhere that is convenient, anytime that is convenient, according to the applicable working hours. 

Unlike remote working or hybrid working, eFisherian is not required to work from home or with a mandatory schedule to the office. Work From Anywhere still leaves the possibility for eFisherian to work anywhere; at home, cafe, co-working space , even at the eFishery Head Office if eFisherian wants to work in the office. 

## Region

Indonesia

## Company technologies

IoT, Aquaculture Intellegence

## Office locations

Bandung, Indonesia. The internet. 

## How to apply

Career site: https://efishery.com/career/