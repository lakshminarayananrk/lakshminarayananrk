# Aerostrat

## Company blurb

Aerostrat was founded in 2015 by both software and airline industry veterans. Our mission is to provide powerful and innovative software that is loved by our customers. Our goal is to be a customer-obsessed, innovative, fast-paced, and transparent company willing to not only listen to our customers but grow with them. We hope that our candid feature discussions, direct developer communication, and 24/7 customer support exemplifies our unique way of working and makes a pleasure to work with as both a customer and a partner.

## Company size

20-50 (Oct 2022)

## Remote status

Fully remote positions available in the United States of America only.

## Region

USA

## Company technologies

Angular, C#, CSS, HTML, JavaScript, .NET, SQL Server, Webpack

## Office locations

- Seattle, WA, USA

## How to apply

https://aerostratsoftware.com/careers/
