# Infinite Red

## Company blurb
We're an app design and development team for mobile and web

[Read more about data, network and features](http://www.infinite.red).

## Company size
30ish

## Remote status
100% Remote - We're proud of it, and we blog about it.  https://mailchi.mp/infinite/remote

## Region
US and Canada freelancers and employees welcome.  NO SOLICITING for farming our work out.  If you'd like to build a bi-directional partnership, let us know.  But we're not outsourcing.

## Company technologies
* JavaScript
* Rails
* Elixir
* Phoenix
* React
* React Native
* ML
* Web Assembly
* C#

## Office locations
100% Remote

## How to apply
Join our community slack (community.infinite.red) and message our CEO.
