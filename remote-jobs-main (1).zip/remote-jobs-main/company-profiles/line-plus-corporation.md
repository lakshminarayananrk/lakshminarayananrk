# LINE Plus Corporation

## Company blurb

LINE Plus Corporation was established in March 2013 in South Korea as a subsidiary of LINE Corporation. It supports LINE’s global business development with programmers, designers, marketers, sales personnel, and PR managers of 50 different nationalities working together.

## Company size

1000+

## Remote status

- You can fully work remotely or work at the office. It's your choice. Depending on COVID-19 situation, 100% remote work could be recommended.
For more information, check out this [link](https://linepluscorp.com/pr/news/ko/2021/3791).
- You should announce your plan at least one day before

## Region

* Republic of Korea

## Company technologies

Android, iOS, Windows, DB, Java, Python, C/C++ , Ad, AI/ML, Blockchain, Fintech, Data, Cloud/Infra, Game, Network, Security, QA

## Office locations

42, Hwangsaeul-ro 360beon-gil, Bundang-gu, Seongnam-si, Gyeonggi-do, Republic of Korea

## How to apply

Please visit our website and see the details.
https://career.linecorp.com/linecorp/career/list
