# Clevertech

## Company blurb

Clevertech have been developing apps since 2000. Clevertech is a team of business analysts, developers and designers. We tackle complex business issues and engineer simplicity. We work with visionary leaders who want full service partners for successful product launches.

## Company size

Nearly 100 employees

## Remote status

100% remote over 6 continents. Schedules are flexible—you work when you're in flow, from wherever you wish.

## Region

[Worldwide](https://clevertech.biz/meet#map-canvas) - A globally located community of talented business analysts, developers and designers.

## Company technologies

JS, node, Python, RoR, PHP, Java,

## Office locations

379 W Broadway, 2nd Floor, New York, NY

## How to apply

Learn [why](https://clevertech.biz/join) you'd want to work at Clevertech, then look to see what the team are [hiring](https://clevertech.biz/careers) for.
