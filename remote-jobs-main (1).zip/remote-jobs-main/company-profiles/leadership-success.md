# Leadership Success

## Company blurb

[Leadership Success](https://www.leadershipsuccess.co/) provides remote leadership coaching and advisory to leaders and HR professionals worldwide.  We've delivered nearly 90,000 hours of virtual coaching to over 15,000 participants from organisations of all shapes and sizes.

## Company size

40+

## Remote status

Leadership success is committed to being 100% remote where possible.  As our service is delivered remotely by staff distrubuted across Australia, the United Kingdom and the United States, we embrace this remote working culture across all aspects of our organisation.

## Region

We currently provide services worldwide

## Company technologies

Javascript, VueJS, Firebase, Node.js, 

## Office locations

We have offices in Sydney Australia and we have offices in London UK & Austin, Texas US

## How to apply

Email us at hello@leadershipsuccess.co
Careers site coming soon
