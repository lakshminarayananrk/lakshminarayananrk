# LogDNA

## Company blurb

LogDNA provides multi-cloud log management solutions.

## Company size

51-100 employees.

## Remote status

Partially remote

