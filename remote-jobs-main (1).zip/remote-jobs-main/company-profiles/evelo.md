# EVELO

## Company blurb
EVELO Electric Bicycle Company develops and distributes long-range, stylish electric bicycles for recreation and commuting. Their electric bikes remove the barriers that keep people from cycling, such as hills, distance, age or fitness levels. The mission is to get more people cycling more often by making bicycles accessible and simple to use.

## Company size
It started with 2 team members.Currently the company is operating with 13 members.


## Remote status
The company is a transportation based.So the web team is handling the work from home and logistics and the maintenance team are working as usual.


## Region
USA


## Company technologies
Head over to the given link and go for the tech stack section.
https://www.zoominfo.com/c/evelo-inc/355361961


## Office locations
1411 34th Ave, Seattle, Washington, 98122, United States


## How to apply
Shoot an email at contact@evelo.com for any queries.

