# Carmatec

## Company blurb
Carmatec, Enterprise Digital transformation solutions company helps businesses with the Digital transformation services and consulting.

## Company size

51-200 employees

## Remote status

The team is remote and in person, located in USA and 3 other countries.

## Region

Los Angeles, USA, INDIA

## Company technologies

Languages & Frameworks
Node.js
Ruby on Rails
JavaScript
HTML5
CSS 3
PHP
Ruby

Development
GitHub
Docker

Libraries

React

Application Hosting

NGINX
Amazon Web Services (AWS)

Data Stores

MySQL
PostgreSQL

Assets and Media
Cloudflare

## How to apply

You can apply here: https://www.carmatec.com/careers/.
