# Lambda School

## Company blurb

### About Us

Lambda School is a 9 month, immersive program that gives you the tools and training you need to launch your new career—from the comfort of your own home.

Student have no loans, no debt, and no up-front tuition. They pay a percentage of income after they're hired, but only if they are making at least $50k/year.

### Our Vision

Unlock everyone’s potential, regardless of circumstance.

## Company size

50-100

## Remote status

Because we train students online, we are 100% remote.

## Region

Remote in North America and Europe, with HQ in San Francisco, CA.

## Company technologies

* Typescript
* Heroku
* Postgres

## Office locations

* 100% Remote
* HQ San Francisco, CA

## How to apply

https://lambdaschool.com/careers/
