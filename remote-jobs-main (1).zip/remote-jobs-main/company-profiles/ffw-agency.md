# FFW Agency

## Company blurb

FFW is a Danish digital agency that serves corporations and governments with the latest web technologies based on PHP, Symfony and Drupal mainly. They also have C# developers team which works on Umbraco CMS.

## Company size

Between 450-650 employees

## Remote status

They have Remote working positions worldwide all the time

## Company technologies

PHP, Symfony, Drupal, JavaScript, jQuery, React, AWS, Azure, Docker, Apache, Solr, MySQL, MariaDB, Rest APIs

## Office locations
Denmark, London, Paris, USA, Bulgaria, Moldova, Ukraine, Romania, Vietnam and have completely remote possitions

## How to apply

[FFW Careers](https://ffwagency.com/careers)
