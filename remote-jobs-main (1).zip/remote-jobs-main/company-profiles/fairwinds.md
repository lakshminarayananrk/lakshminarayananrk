# Fairwinds Ops

## Company blurb

Fairwinds is the trusted partner for Kubernetes security, policy and governance. With Fairwinds, customers ship cloud native applications faster, more cost effectively and with less risk. We provide a unified view between dev, sec and ops removing friction between those teams with software that simplifies complexity.

## Company size

30-70 employees

## Remote status

Remote first

## Region

Most of the team is located in the USA, exceptions are handled on a case by case basis.

## Company technologies

Kubernetes, GoLang, Vue

## Office locations

None

## How to apply

[Careers Page](https://www.fairwinds.com/careers)
