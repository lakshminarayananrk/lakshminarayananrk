# folotop

## Company blurb

We are committed to excellence in research and analysis. Our team of experts works tirelessly to curate comprehensive rankings and categorizations across a wide spectrum of categories. We believe that excellence should be accessible to all, and we’re here to guide you on that journey.

## Company size

10-30

## Remote status

We are a small, fully remote working content writer and marketing person required.

## Region

Worldwide

## Company technologies

Our current toolset includes WordPress and SEO and Marketing.

## How to apply

We are looking for an employee, you just need to visit below link and need to fill the form.
1. https://www.folotop.com/job/
2. Click on the apply button and fill the form and we will get in touch with you.
