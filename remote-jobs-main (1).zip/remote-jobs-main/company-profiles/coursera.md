# Coursera

## Company blurb

Coursera is a global online learning platform that offers anyone, anywhere, access to online courses and degrees from leading universities and companies.

## Company size

1000+

## Remote status

Coursera is hiring remote engineers across North America.

## Region

* USA
* Canada

## Company technologies

Java, Scala

## Office locations

Multiple offices worldwide. Headquarters in Mountain View, California, USA.

## How to apply

https://about.coursera.org/careers/
