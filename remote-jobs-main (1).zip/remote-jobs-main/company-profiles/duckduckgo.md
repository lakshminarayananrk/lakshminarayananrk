# DuckDuckGo

## Company blurb

We are the Internet privacy company that lets you take control of your information, without any tradeoffs. Welcome to the Duck Side!

## Company size

Around 50

## Remote status

Fully remote with at least one company-wide meetup

## Region

Worldwide

See our about page to see where people are based: https://duckduckgo.com/about


## Company technologies

Perl, HTML, JavaScript, CSS, Kotlin, Swift

## Office locations

* Paoli, Philadelphia, PA, USA
* Toronto, Ontario, Canada

## How to apply

Check out our current openings on our careers page.

https://duckduckgo.com/hiring/

