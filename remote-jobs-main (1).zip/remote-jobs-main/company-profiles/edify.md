# Edify

## Company blurb
We believe that we live in a knowledge powered world and by combining some of the most talented computer scientists we can engage the forefront of education technology.

## Company size

36 team members listed on the [team page](http://www.edify.cr/ourteam);

We have 21 dogs, 15 cats, 28 fish, and a duck named “fish”. We have 23 kids, two of them twins and a few more on the way. We are bikers, athletes, nerds and one of us is a great cook.

## Remote status

Work from anywhere.
Even though Edify is located in Costa Rica, everyone works from where they love to be. We're always in close contact through our Slack, Skype and Google Hangouts.

## Region

Costa Rica, US, Anywhere.

## Company technologies

Java, PHP, Ruby, JavaScript, Go, and anything that solves our client's needs.

## Office locations

- Alajuela, Costa Rica.
- Atlanta, Georgia, US.

## How to apply

Information and job listings are listed on [Join the team](http://www.edify.cr/joinus)
