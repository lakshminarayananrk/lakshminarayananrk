# Intellum

## Company blurb

Here at Intellum we help companies increase revenue and improve customer retention. As we combine customer experience and education we help large brands and fast-moving companies to achieve thier business outcomes. 

For 20 years we have been succeeding in our mission through observing and rethinking how people learn and collaborate. Founded in the year 2000 we launched the world's first cloud LMS (Learning Management System) and threafter through the years introducing cloud course and assessment authoring, delivering course and assessments over the web, development of the Tribe Social and Tribe Chat... and much more.

Company Website: https://www.intellum.com/

## Company size

51-200 Employees.

## Remote status

Currently no remote options/positions.

## Region

USA.

## Company technologies

HTML
CSS
JavaScript
ReactJS
GIT

## Office locations

USA - Atlanta, Georgia.

## How to apply

You can see a listing of opportunities here https://apply.workable.com/intellum-inc/ and on Intellum's LinkedIn profile.
Intellum's website does not seem to have a career opportunity section.




