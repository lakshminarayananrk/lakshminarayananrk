# iClinic

## Company blurb

iClinic is one of the fastest growing health technology startups in Brazil. We serve thousands of professionals around the country. 

## Company size

50-100

## Remote status

The most of development and product team are fully remote. You can find more information in our [career instagram](https://www.instagram.com/carreirasiclinic/?hl=en)

## Region

Currently, we only accept portuguese speakers candidates that can work in a time range compatible with the BRT (UTC -3) business hours.

## Company technologies

Python, Django, Node, React, Redux, Postgres and MySQL

## Office locations

Ribeirão Preto, PR, Brazil

## How to apply

Visit our [career page](https://vagas.iclinic.com.br/).
