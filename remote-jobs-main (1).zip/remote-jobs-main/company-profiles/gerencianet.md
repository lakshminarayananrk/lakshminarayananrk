# Gerencianet

## Company blurb

Gerencianet is a digital account focused on business so that entrepreneurs can issue and manage receipts. Currently, it is responsible for issuing more than 130 million annual charges and has 290 thousand registered customers throughout Brazil.

The company is certified as a great place to work by the consultancy Great Place to Work.

Gerencianet believes in and values human potential. Therefore, it offers employees a pleasant environment that promotes development and integration.

## Company size

201-500 employees

## Remote status

The vacancies, both in technology and in other areas, are mostly for remote work. People can freely choose where they prefer to work, remotely or in person.
 
## Region

Brazil

## Company technologies

HTML, CSS, JavaScript, PHP, SQL, communication structures (JSON/XML), webservices, OAuth, API integrations.

## Office locations

Gerencianet is headquartered in Ouro Preto and has offices in São Paulo, Belo Horizonte and Recife.

## How to apply

[Work with us](https://gerencianet.com.br/trabalheconosco)
