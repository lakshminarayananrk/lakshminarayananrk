# Abstract

## Company blurb

Abstract provides a suite of fast and robust APIs for developers with extensive free plan for solo hackers.

From holiday data to screenshot APIs, Abstract helps developers from freelancers to dev teams in companies like Google and Shopify, automate their workflow or build delightful experiences.

## Company size

1-10

## Remote status

The team is currently fully remote, located in the US, Argentina and Canada.
The team is planning on hiring more people in Europe in particular in 2020 and 2021.

## Region

Worldwide

## Company technologies

Python, Django, Postres, Redis, AWS lambda

## How to apply

Email contact@abstractapi.com with subject "Application (remoteintech)" or contact the team through their live chat on [Abstract API website](https://www.abstractapi.com).
