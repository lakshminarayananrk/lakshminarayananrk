# Full Fabric

## Company blurb

Full Fabric helps top universities around the globe to deliver a world-class education experience. An integrated solution for the university that understands the need to refocus on the student experience.

## Company size

0-20 employees.

## Remote status

We are headquartered in London but have developers in Europe. We communicate through Slack, Google Hangouts, Screenhero, or Asana.

## Region

Europe

## Company technologies

- Ruby/Rails
- MongoDB
- Backbone w/ Marionette
- Coffeescript
- Sass

## Office locations

London, UK

## How to apply

Join us [anytime](http://fullfabric.com/careers)!