# GitPrime

## Company blurb

GitPrime is an analytics platform for software engineering performance.

## Company size

0 – 20

## Remote status

We are very remote friendly, with the majority of our engineering team
currently remotely located.

## Region

We are region-agnostic, and simply look to hire the best engineers in the
world, regardless of location.

## Company technologies

Python, Django, JavaScript, Angular, D3.js

## Office locations

Colorado, USA

## How to apply

Go to https://gitprime.com/jobs/
