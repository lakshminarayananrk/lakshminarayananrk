# Kaggle

## Company blurb

Kaggle, a subsidiary of Google LLC, is an online community of data scientists and machine learning practitioners.
It hosts data science competitions with hefty prize money.

## Company size

50-100

## Remote status

It offers remote work too.

## Region

San Fransisco or remote


## Office locations

California ; or everywhere!

## How to apply

Check out our [careers page](https://www.kaggle.com/about/careers).
