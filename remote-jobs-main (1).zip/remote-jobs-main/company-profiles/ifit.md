# iFit

## Company blurb

At iFit we do remote teams right. Join a great company that is growing fast and with the right work/life balance.


We believe in sustainable, healthy lifestyles that deliver results. iFit focuses on connecting everybody to everything fitness. We love software that talks to real things. Our parent company is the world's largest fitness manufacturer ( iFit,NordicTrack, ProForm, Gold's Gym, Freemotion, 10+ others), which provides us a LOT of devices,  embedded tablets, and other exciting physical things to engage with.

## Company size

close to 200 (Nov 2019)

## Remote status

Almost all of the developers are remote. We do have an office in Logan, Utah, where the product owners, testers, and higher ups are based.

## Region

USA

## Company technologies

React + TypeScript for Full Stacks, C#/Xamarin and Kotlin for Mobile Devs.

## Office locations

Logan, Utah

## How to apply

Check our jobs page: https://www.iconfitness.com/careers.html?brand=ifit
