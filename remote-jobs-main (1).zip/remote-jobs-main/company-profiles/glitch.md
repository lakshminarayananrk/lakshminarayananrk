# Glitch

## Company blurb

We started out as Fog Creek Software, a pioneering independent tech company that has always put people first.

Our team invented Trello, co-created Stack Overflow, and launched many other groundbreaking apps that collectively have made us one of the most influential small tech companies ever.

## Company size

30+

## Remote status

Unless a job listing says otherwise, Remote-friendly - Worldwide.

## Region

Worldwide

## Company technologies

- c#
- jquery
- python
- javascript
- sql-server
- elasticsearch
- redis
- mercurial
- git
- f#
- node.js
- mongodb
- websocket
- coffeescript
- html5
- express.js
- haproxy
- .net
- asp.net-mvc
- docker
- golang
- ruby

## Office locations

New York, NY

## How to apply

[Apply here](https://glitch.bamboohr.com/jobs/)

