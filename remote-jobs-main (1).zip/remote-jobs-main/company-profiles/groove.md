# Groove HQ

## Company blurb

Serving more than 8,000 businesses, Groove is a Saas product which makes it easy for teams to manage customer service at scale.

## Company size

11-50

## Remote status

GrooveHQ is a fully-remote team, with 19 team members spread across 13 cities and 5 continents. They do not have an office.

## Region

Hires worldwide.

## Company technologies

Rails, GraphQL, React, Redux

## Office locations

No physical office

## How to apply

[GrooveHQ Jobs](https://www.groovehq.com/about#hiring)
