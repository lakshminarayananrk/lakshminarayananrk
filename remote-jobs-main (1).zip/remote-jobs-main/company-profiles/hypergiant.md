# Hypergiant

## Company blurb

Hypergiant offers services that include innovative technologies of Robotic Process Automation equipped with smart learning. Hyper Giant offers solutions for aerospace, energy cyber security, healthcare, shipping, manufacturing, transportation, automotive, pharmaceuticals, telecommunications and banking.

Hypergiant was previous Black Pixel.

## Company size

220

## Remote status

Mostly remote.

## Region

**USA**

## Company technologies

* AI Automation
* Smart learning technologies
* Data service
* Sensor Technologies

## Office locations
 
101 W 6TH ST #400
AUSTIN, TX 78701
and
5350 ALPHA ROAD
DALLAS, TEXAS 75240


## How to apply

See [this](https://www.hypergiant.com/careers/) page for job inquiry (available currently).
