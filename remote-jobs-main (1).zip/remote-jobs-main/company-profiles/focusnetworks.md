# Focusnetworks

## Company blurb

Focusnetworks is a Digital Business Group that unites Marketing and Technology to help clients take their business to the next level using digital medium. In order to do that, many solutions are presented, like Project Development (such as systems, applications, portals and websites), Digital Strategic Planning, Web Projects, Digital Marketing, Apps for Social Networking , Mobile Apps, Social Media, Media Automation, Measurement, Innovation in Online Media: solutions with effective results.

## Company size

11-50, according to [crunchbase](https://www.crunchbase.com/organization/focusnetworks)

## Remote status

Remote job opportunities available.

## Region
Worldwide

## Company technologies

- Google Ads, Facebook Ads
- Google Analytics and Google Data Studio
- MS Office

## Office locations

Avenue Cassiano Ricardo, 401
1109
São José dos Campos, São Paulo 12246870, Brazil

## How to apply

https://focusnetworks.enlizt.me/?utm_source=jooble&utm_medium=cpc&utm_campaign=jooble