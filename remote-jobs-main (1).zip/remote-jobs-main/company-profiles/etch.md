# Etch

## Company blurb

Make better software.
[Etch](https://etch.co) is a boutique, distributed, web-software agency loosely based in the south-east UK.

## Company size

3 team members shown on the [team page](https://etch.co/team), soon to be more!

## Remote status

We're a fully remote team, although we do like to get together and hang out in real life a few times a year.

## Region

United Kingdom of Great Britain and Northern Ireland, Europe

## Company technologies

React, Angular, GraphQL, Node, Docker

## Office locations

None at the moment, but we might be setting up a coffeeshop and co-working space in 2019.

## How to apply

Can you software? We're currently looking for a [Front-end Developer](https://etch.co/jobs), but we're always interested to speak to awesome people.
