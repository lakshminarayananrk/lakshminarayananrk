# BeBanjo

## Company blurb

At BeBanjo, we strive to make our customers great at putting video content online. We build easy to use, powerful web applications to manage video on-demand (VOD) services. Our customers are broadcasters, Hollywood studios and platform operators in Europe, the US and Australia. They include BT TV, Channel 5, Orange, BBC Studios and Turner, to name a few. We believe we offer the best products in the world for companies running large VOD services.

## Remote status

We work remotely using Slack, GitHub, Hangouts and our homemade tools. But if we feel like going to an office, we have one in London and another one in Madrid.

## Region
Worldwide - work from anywhere

## Office locations

* Doctor Fourquet 27, local Izq. 28012 Madrid (Spain)
* 26 Leonard Street, London, EC2A 4BY (UK)
* 3000 Olympic Blvd
Santa Monica, CA 90404 (USA)

## How to apply

Visit [Bebanjo Careers page](https://bebanjo.com/careers/) for information on how to apply.

