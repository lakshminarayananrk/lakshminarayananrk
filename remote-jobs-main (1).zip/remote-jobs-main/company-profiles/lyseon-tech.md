# Lyseon Tech

## Company blurb

We develop digital products with agility, innovation and technical quality, so that the Brazilian market keeps pace with the worldwide technological growth.
In our team we have highly qualified professionals and nationally recognized specialists to make your dreams come true through technology.
## Company size

12 employees (January 2018).

## Remote status

We work 100% remote, we work at home and in cowork

## Region

Brazil

## Company technologies

* PHP
* PostgreSQL
* Laravel
* Symfony
* Docker
* MySQL
* MariaDB
* MongoDB
* JavaScript
* Nginx
* Apache
* Redis
* WordPress
* Git

## Office locations

Brazil, Rio de Janeiro

## How to apply

Check our jobs page: http://lt.coop.br/

If your position isn't listed, create it by emailing vagas@lt.coop.br and starting a conversation.
