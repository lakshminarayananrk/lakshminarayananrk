# Lytx

## Company blurb
Lytx is a San Diego based company that uses machine learning to collect data and improve security for drivers.

## Company size
600+ (as of 2020)

## Remote status
Software Engineering roles are currently remote.

## Region
USA, UK, Israel

## Company technologies
Depends on role

## Office locations
San Diego, CA

## How to apply
https://www.lytx.com/en-us/about-us/careers