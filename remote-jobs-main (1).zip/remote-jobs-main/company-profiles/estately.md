# Estately

## Company blurb
Estately is a startup based in US that primarily focuses on rental apartments and property selling works.It is a national real estate company that’s revolutionizing the home buying experience. Home buyers can search through millions of listings in 39 states on Estately.com or with the Estately App for iPhone, iPad and Apple Watch. Shopping for a home doesn’t have to be stressful.

With Estately it can be simple, reliable and fun.They focus on connecting people with the best real estate agents they can find in any given area. Unlike some of the big real estate sites, they aren’t ad-based, so agents don’t pay to be on our property pages.They focus on creating a simple experience with just the information that the customers need, and they’re updates their listings as fast as possible.

## Company size
0-100

## Remote status

Not completely remote,some of the employees are working from home.

## Region
USA

## Company technologies
Head over to the given link to find more information.
https://stackshare.io/estately/estately


## Office locations

Estately, Inc.
P.O. Box 23181
Seattle, WA, 98102

## How to apply

We’re not hiring right now, but we’re glad you’re considering joining our crew. Please send your resume to jobs@estately.com, and we’ll consider you in the future.