# Flowing

## Company blurb

We design and implement projects to accelerate growth and innovation for our clients.
Our team are cross functional: business strategy, UX, development, operations, all working together with our clients 

## Company size

40 (as of October 2020)

## Remote status

Full remote, you can choose to work wherever you like, being your home or a coworking. We do have flexible working hours, so it is important to have good communication skills, both synchronous and asynchronous.

We do do have a registered office in Ancona, but it is not used as operating office. When team's members feel the need to meet in person we exploit the most convenient coworking nearby

## Region

Italy. We are distributed all across the region, thought the majority of us is located in central north

## Company technologies

We consider ourselves Agile and Lean pratictioners from top to bottom focusing on delivering the best value we can
We truly believe trust is the key for successful projects, we always aim to build a trust relationship with our clients

We feel comfortable with several web related technologies  

backend: Javascript, Typescript, Java, PHP

frontend: Javascript and Typescript 

mobile: native and hybrid

cloud: AWS

## Office locations

The internet. 

## How to apply

Contact Us: https://www.flowing.it/job-opportunity
